# JBoss 7.3 to 8.0 Migration Tools

This package contains two helper scripts:

1. **copy-custom-modules.sh**
   - Copies all custom modules from JBoss 7.3 to JBoss 8.0.

2. **validate-modules.sh**
   - Validates if any module dependencies are missing after copying.

## Usage

- Edit both scripts and set the correct paths for JBOSS7_HOME and EAP8_HOME.
- Give execute permission: `chmod +x copy-custom-modules.sh validate-modules.sh`
- Run scripts as needed.

