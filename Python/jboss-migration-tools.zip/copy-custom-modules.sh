#!/bin/bash

# Set your old and new JBoss home directories
JBOSS7_HOME=/path/to/jboss-eap-7.3
EAP8_HOME=/path/to/jboss-eap-8.0

# Find custom modules (excluding standard ones)
find "$JBOSS7_HOME/modules/" -name "module.xml" \
| grep -v "/system/" \
| grep -v "/javax/" \
| grep -v "/org/jboss/" \
| grep -v "/org/wildfly/" \
| while read module_xml; do
    module_path=$(dirname "${module_xml#$JBOSS7_HOME/modules/}")
    echo "Copying module: $module_path"
    mkdir -p "$EAP8_HOME/modules/$module_path"
    cp -r "$JBOSS7_HOME/modules/$module_path/"* "$EAP8_HOME/modules/$module_path/"
done

echo "Custom modules copied successfully!"
