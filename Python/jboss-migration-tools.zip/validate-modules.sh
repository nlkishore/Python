#!/bin/bash

# Set EAP8_HOME to your new JBoss 8.0 installation
EAP8_HOME=/path/to/jboss-eap-8.0

echo "Checking module dependencies..."

find "$EAP8_HOME/modules/" -name "module.xml" \
| grep -v "/system/" \
| grep -v "/javax/" \
| grep -v "/org/jboss/" \
| grep -v "/org/wildfly/" \
| while read module_xml; do
    module_dir=$(dirname "${module_xml}")
    echo "Validating module: ${module_dir#$EAP8_HOME/modules/}"
    
    grep "<module name=" "$module_xml" | while read dep_line; do
        dep_module=$(echo "$dep_line" | sed -n 's/.*<module name=\"\([^\"]*\)\".*/\1/p')
        if [ ! -d "$EAP8_HOME/modules/${dep_module//.//}/main" ]; then
            echo "  >> Missing dependency: $dep_module"
        fi
    done
done

echo "Validation complete."
