#!/usr/bin/env python3
"""
jardiff - decompile old vs new jars and produce a browsable HTML diff report.

Built for the GEB CVE remediation release. For every jar in manifest.json it:
  1. resolves the old and new jar (local ./jars/<old|new>/ first, else downloads from Maven Central)
  2. decompiles both with CFR (Java decompiler)
  3. diffs class-by-class
  4. writes an HTML report you can open in a browser (index + one page per library)

Usage:
  python3 jardiff.py                 # run every item in the manifest
  python3 jardiff.py --only nimbus-jose-jwt json-smart commons-io
  python3 jardiff.py --skip aspectjtools     # skip the big slow one
  python3 jardiff.py --japicmp       # also run japicmp API-change summary per replaced pair

Requires: Java (to run CFR) and Python 3.8+. No other installs.
"""

import argparse
import html
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from difflib import unified_diff
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT / "tools"
JARS = ROOT / "jars"
WORK = ROOT / ".work"          # decompiled sources land here
OUT = ROOT / "output"
CFR_VERSION = "0.152"
CFR_JAR = TOOLS / f"cfr-{CFR_VERSION}.jar"
CFR_URL = f"https://repo1.maven.org/maven2/org/benf/cfr/{CFR_VERSION}/cfr-{CFR_VERSION}.jar"
JAPICMP_VERSION = "0.23.1"
JAPICMP_JAR = TOOLS / f"japicmp-{JAPICMP_VERSION}-jar-with-dependencies.jar"
JAPICMP_URL = (f"https://repo1.maven.org/maven2/com/github/siom79/japicmp/japicmp/"
               f"{JAPICMP_VERSION}/japicmp-{JAPICMP_VERSION}-jar-with-dependencies.jar")
CENTRAL = "https://repo1.maven.org/maven2"


def log(msg):
    print(msg, flush=True)


def download(url, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "jardiff/1.0"})
    with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f)


def ensure_cfr():
    if CFR_JAR.exists():
        return
    log(f"[setup] downloading CFR {CFR_VERSION} ...")
    try:
        download(CFR_URL, CFR_JAR)
    except Exception as e:
        sys.exit(f"[fatal] could not download CFR from Maven Central ({e}).\n"
                 f"        Manually place cfr-{CFR_VERSION}.jar in {TOOLS} and re-run.")


def ensure_japicmp():
    if JAPICMP_JAR.exists():
        return True
    log(f"[setup] downloading japicmp {JAPICMP_VERSION} ...")
    try:
        download(JAPICMP_URL, JAPICMP_JAR)
        return True
    except Exception as e:
        log(f"[warn] japicmp download failed ({e}); skipping API summary.")
        return False


def maven_url(group, artifact, version):
    gpath = group.replace(".", "/")
    return f"{CENTRAL}/{gpath}/{artifact}/{version}/{artifact}-{version}.jar"


def resolve_jar(group, artifact, version, side):
    """Find the jar locally (jars/<side>/) or download it from Central. Returns Path or None."""
    if version is None:
        return None
    local_dir = JARS / side
    local_dir.mkdir(parents=True, exist_ok=True)
    candidate = local_dir / f"{artifact}-{version}.jar"
    if candidate.exists():
        log(f"    [{side}] using local {candidate.name}")
        return candidate
    # try a couple of loose local matches (in case of classifier differences)
    for p in local_dir.glob(f"{artifact}-{version}*.jar"):
        log(f"    [{side}] using local {p.name}")
        return p
    url = maven_url(group, artifact, version)
    log(f"    [{side}] downloading {artifact}-{version}.jar ...")
    try:
        download(url, candidate)
        return candidate
    except Exception as e:
        log(f"    [{side}] DOWNLOAD FAILED ({e}) -> {url}")
        log(f"    [{side}] drop {artifact}-{version}.jar into {local_dir} and re-run.")
        return None


def decompile(jar_path, dest):
    """Decompile a jar to dest dir with CFR. Returns dest."""
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    cmd = ["java", "-jar", str(CFR_JAR), str(jar_path),
           "--outputdir", str(dest), "--silent", "true", "--comments", "false"]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    return dest


def collect_sources(root):
    """Map relative .java path -> file content for every decompiled source under root."""
    out = {}
    if not root.exists():
        return out
    for p in root.rglob("*.java"):
        rel = p.relative_to(root).as_posix()
        try:
            out[rel] = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            out[rel] = ""
    return out


def diff_class(rel, old_text, new_text):
    old_lines = old_text.splitlines(keepends=False)
    new_lines = new_text.splitlines(keepends=False)
    ud = list(unified_diff(old_lines, new_lines, fromfile=f"a/{rel}", tofile=f"b/{rel}", lineterm=""))
    return ud


# ----------------------------- HTML rendering -----------------------------

CSS = """
:root { --add:#1a7f37; --del:#cf222e; --hunk:#0969da; --bg:#0d1117; --fg:#e6edf3;
        --panel:#161b22; --border:#30363d; --muted:#8b949e; }
* { box-sizing: border-box; }
body { margin:0; background:var(--bg); color:var(--fg);
       font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif; }
a { color:#58a6ff; text-decoration:none; } a:hover { text-decoration:underline; }
.wrap { max-width:1100px; margin:0 auto; padding:24px; }
h1 { font-size:22px; } h2 { font-size:18px; border-bottom:1px solid var(--border); padding-bottom:6px; }
.meta { color:var(--muted); font-size:13px; margin-bottom:18px; }
table { border-collapse:collapse; width:100%; margin:12px 0; font-size:14px; }
th,td { text-align:left; padding:8px 10px; border-bottom:1px solid var(--border); }
th { color:var(--muted); font-weight:600; }
.badge { display:inline-block; padding:1px 8px; border-radius:10px; font-size:12px; font-weight:600; }
.b-replaced{background:#1f2937;color:#9ecbff;} .b-added{background:#0f2f1a;color:#6fdd8b;}
.b-removed{background:#3a1113;color:#ff9a9a;} .b-nochange{background:#22262d;color:#8b949e;}
.num { font-variant-numeric:tabular-nums; }
.chg{color:#e3b341;} .add{color:var(--add);} .del{color:var(--del);}
details { background:var(--panel); border:1px solid var(--border); border-radius:8px;
          margin:8px 0; padding:0 12px; }
summary { cursor:pointer; padding:10px 0; font-weight:600; font-family:ui-monospace,SFMono-Regular,Menlo,monospace; font-size:13px; }
pre.diff { margin:0 0 12px; padding:12px; overflow-x:auto; background:#0b0f14;
           border-radius:6px; font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
           font-size:12.5px; line-height:1.45; }
pre.diff .l-add{color:var(--add);} pre.diff .l-del{color:var(--del);} pre.diff .l-hunk{color:var(--hunk);}
.summary-cards{display:flex;gap:12px;flex-wrap:wrap;margin:10px 0 20px;}
.card{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:12px 16px;min-width:120px;}
.card .n{font-size:22px;font-weight:700;} .card .k{color:var(--muted);font-size:12px;}
.back{font-size:13px;}
"""


def render_diff_pre(ud_lines):
    rows = []
    for ln in ud_lines:
        cls = ""
        if ln.startswith("+++") or ln.startswith("---"):
            cls = ""
        elif ln.startswith("@@"):
            cls = "l-hunk"
        elif ln.startswith("+"):
            cls = "l-add"
        elif ln.startswith("-"):
            cls = "l-del"
        rows.append(f'<span class="{cls}">{html.escape(ln)}</span>')
    return '<pre class="diff">' + "\n".join(rows) + "</pre>"


def badge(status):
    return f'<span class="badge b-{status}">{status}</span>'


def write_detail_page(item, result):
    art = item["artifact"]
    slug = art.replace(".", "_")
    fname = OUT / f"{slug}.html"
    changed = result["changed"]
    added = result["added"]
    removed = result["removed"]

    parts = [f"""<!doctype html><html><head><meta charset="utf-8">
<title>{html.escape(art)} diff</title><style>{CSS}</style></head><body><div class="wrap">
<div class="back"><a href="index.html">&larr; all libraries</a></div>
<h1>{html.escape(item['group'])}:{html.escape(art)} &nbsp; {badge(item['status'])}</h1>
<div class="meta">{html.escape(str(item.get('old')))} &rarr; {html.escape(str(item.get('new')))}
 &nbsp;|&nbsp; {html.escape(item.get('reason',''))}</div>
<div class="summary-cards">
  <div class="card"><div class="n chg">{len(changed)}</div><div class="k">classes changed</div></div>
  <div class="card"><div class="n add">{len(added)}</div><div class="k">classes added</div></div>
  <div class="card"><div class="n del">{len(removed)}</div><div class="k">classes removed</div></div>
</div>"""]

    if item["status"] == "nochange":
        parts.append('<p class="meta">No version change in this release. Nothing to diff.</p>')

    if changed:
        parts.append("<h2>Changed classes</h2>")
        for rel, ud in changed:
            parts.append(f"<details><summary>{html.escape(rel)}</summary>{render_diff_pre(ud)}</details>")
    if added:
        parts.append("<h2>Added classes</h2>")
        for rel in added:
            parts.append(f'<details><summary class="add">+ {html.escape(rel)}</summary>'
                         f'<pre class="diff"><span class="l-add">new class present only in {html.escape(str(item.get("new")))}</span></pre></details>')
    if removed:
        parts.append("<h2>Removed classes</h2>")
        for rel in removed:
            parts.append(f'<details><summary class="del">- {html.escape(rel)}</summary>'
                         f'<pre class="diff"><span class="l-del">class existed only in {html.escape(str(item.get("old")))}; gone in this release</span></pre></details>')

    if result.get("japicmp_html"):
        parts.append('<h2>API change summary (japicmp)</h2>')
        parts.append(f'<div><a href="{slug}_japicmp.html" target="_blank">open full japicmp report &rarr;</a></div>')

    parts.append("</div></body></html>")
    fname.write_text("\n".join(parts), encoding="utf-8")
    return fname.name


def write_index(results, meta):
    rows = []
    for item, res in results:
        slug = item["artifact"].replace(".", "_")
        c, a, r = len(res["changed"]), len(res["added"]), len(res["removed"])
        link = item["artifact"]
        if item["status"] != "nochange" and res.get("rendered"):
            link = f'<a href="{slug}.html">{html.escape(item["artifact"])}</a>'
        else:
            link = html.escape(item["artifact"])
        rows.append(
            f"<tr><td class='num'>{item['sno']}</td><td>{link}</td>"
            f"<td>{html.escape(str(item.get('old')))} &rarr; {html.escape(str(item.get('new')))}</td>"
            f"<td>{badge(item['status'])}</td>"
            f"<td class='num chg'>{c}</td><td class='num add'>{a}</td><td class='num del'>{r}</td>"
            f"<td class='meta'>{html.escape(item.get('reason',''))}</td></tr>"
        )
    page = f"""<!doctype html><html><head><meta charset="utf-8">
<title>{html.escape(meta.get('release','jar diff'))}</title><style>{CSS}</style></head><body><div class="wrap">
<h1>{html.escape(meta.get('release','jar diff report'))}</h1>
<div class="meta">Generated {time.strftime('%Y-%m-%d %H:%M')} &nbsp;|&nbsp; decompiler: CFR {CFR_VERSION}</div>
<table>
<tr><th>#</th><th>Library</th><th>Version</th><th>Status</th><th>Chg</th><th>Add</th><th>Rem</th><th>Note</th></tr>
{''.join(rows)}
</table>
<div class="meta">Click a library to read the class-by-class decompiled diff.</div>
</div></body></html>"""
    (OUT / "index.html").write_text(page, encoding="utf-8")


# ----------------------------- japicmp -----------------------------

def run_japicmp(old_jar, new_jar, slug):
    out_html = OUT / f"{slug}_japicmp.html"
    cmd = ["java", "-jar", str(JAPICMP_JAR), "-o", str(old_jar), "-n", str(new_jar),
           "--html-file", str(out_html), "--ignore-missing-classes"]
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False, timeout=600)
        return out_html.exists()
    except Exception:
        return False


# ----------------------------- main -----------------------------

def process_item(item, do_japicmp):
    art = item["artifact"]
    status = item["status"]
    result = {"changed": [], "added": [], "removed": [], "rendered": False, "japicmp_html": False}

    if status == "nochange":
        log(f"[{item['sno']:>2}] {art}: no change, skipped")
        result["rendered"] = True
        return result

    old_jar = resolve_jar(item["group"], art, item.get("old"), "old")
    new_jar = resolve_jar(item["group"], art, item.get("new"), "new")

    old_src, new_src = {}, {}
    if old_jar:
        old_src = collect_sources(decompile(old_jar, WORK / f"{art}__old"))
    if new_jar:
        new_src = collect_sources(decompile(new_jar, WORK / f"{art}__new"))

    old_keys, new_keys = set(old_src), set(new_src)
    result["added"] = sorted(new_keys - old_keys)
    result["removed"] = sorted(old_keys - new_keys)
    for rel in sorted(old_keys & new_keys):
        if old_src[rel] != new_src[rel]:
            ud = diff_class(rel, old_src[rel], new_src[rel])
            if ud:
                result["changed"].append((rel, ud))

    if do_japicmp and old_jar and new_jar:
        slug = art.replace(".", "_")
        if run_japicmp(old_jar, new_jar, slug):
            result["japicmp_html"] = True

    log(f"[{item['sno']:>2}] {art}: {len(result['changed'])} changed, "
        f"{len(result['added'])} added, {len(result['removed'])} removed")
    return result


def main():
    ap = argparse.ArgumentParser(description="decompile + diff old vs new jars into an HTML report")
    ap.add_argument("--only", nargs="*", help="only these artifact names")
    ap.add_argument("--skip", nargs="*", default=[], help="skip these artifact names")
    ap.add_argument("--japicmp", action="store_true", help="also run japicmp API-change summary")
    ap.add_argument("--manifest", default=str(ROOT / "manifest.json"))
    args = ap.parse_args()

    meta = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    items = meta["items"]
    if args.only:
        want = set(args.only)
        items = [i for i in items if i["artifact"] in want]
    if args.skip:
        skip = set(args.skip)
        items = [i for i in items if i["artifact"] not in skip]
    if not items:
        sys.exit("nothing to do (check --only / --skip names)")

    ensure_cfr()
    do_japicmp = args.japicmp and ensure_japicmp()
    OUT.mkdir(parents=True, exist_ok=True)
    WORK.mkdir(parents=True, exist_ok=True)

    results = []
    t0 = time.time()
    for item in items:
        res = process_item(item, do_japicmp)
        if item["status"] != "nochange":
            res["rendered"] = True
            write_detail_page(item, res)
        results.append((item, res))

    write_index(results, meta)
    # clean decompiled scratch to keep the folder small; comment out to inspect raw sources
    shutil.rmtree(WORK, ignore_errors=True)
    log(f"\nDone in {time.time()-t0:.1f}s. Open: {OUT / 'index.html'}")


if __name__ == "__main__":
    main()
