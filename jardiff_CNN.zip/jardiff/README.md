# jardiff — CN release jar diff suite

Decompiles the **old** and **new** version of every jar in this release and produces a
browsable HTML report so you can read the actual class-level logic changes — not just
version numbers.

Built for the GEB CVE remediation (CN, SD v1.4). Covers all 19 line items from
commons-fileupload through nimbus, json-smart, spring, aspectj, activemq, velocity.

## Requirements
- Java (any 8+; used only to run the decompiler) — `java -version`
- Python 3.8+ — `python3 --version`
- Internet access to Maven Central (your laptop) — for jars not already local

CFR (the decompiler) is **already bundled** in `tools/`, so nothing to install.

## Quick start
```
cd jardiff
python3 jardiff.py
```
Then open `output/index.html` in a browser.

First run downloads each old+new jar from Maven Central automatically. Re-runs reuse
what's already in `jars/`.

## What you get
- `output/index.html` — one table: every library, old→new, and a count of classes
  **changed / added / removed**. Your at-a-glance risk view.
- `output/<library>.html` — click any library to read the class-by-class diff.
  Changed classes are collapsible; green = added lines, red = removed lines.

## Useful options
```
python3 jardiff.py --only nimbus-jose-jwt json-smart commons-io commons-fileupload
        # run just the meaty / risky ones first

python3 jardiff.py --skip aspectjtools
        # aspectjtools is a large jar (contains the ajc compiler) and is the slow one

python3 jardiff.py --japicmp
        # also generate a japicmp API-change summary per replaced pair
        # (clean "methods/classes added/removed/modified" view; downloads japicmp once)
```

## Sourcing jars
The tool looks in `jars/old/<artifact>-<oldver>.jar` and `jars/new/<artifact>-<newver>.jar`
first. If a jar isn't there, it downloads from Maven Central. If a download ever fails
(offline, proxy, whatever), it prints the exact filename to drop into `jars/old` or
`jars/new`, then just re-run.

## Notes per special item
- **activemq-core (removed):** no new jar, so the report lists its classes as *removed* —
  a quick inventory of exactly what leaves the classpath.
- **accessors-smart (added):** no old jar, so its classes show as *added*.
- **velocity 1.7 (no change):** skipped (nothing to diff).
- **spring 5.3.27 → 5.3.34:** expect only a handful of changed classes per jar — that
  small footprint *is* the reassurance that a patch bump isn't hiding surprises.
- **nimbus 7.9 → 9.37.4** and **json-smart 1.3.1 → 2.5.0:** the big diffs (major jumps).
  This is where reading the actual logic pays off.

## Edit scope
`manifest.json` drives everything — versions, coordinates, and status. Adjust there if a
version in the SD changes before go-live.
