package com.misys.portal.uob.interfaces.incoming;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * REVIEW CHANGES IN THIS FILE
 *
 * [GHT-18] REMOVED the log-fragment constants: LOGIN_ID_START, LOGIN_ID_PARAM, COMPANY_ID_PARAM,
 *          GROUP_ABBV_PARAM, USER_ID_PARAM, NEW_SERIAL_LOG_PARAM, OLD_SERIAL_LOG_PARAM,
 *          USER_ID_LOG_PARAM. Four near-identical constants for two fields, where the correct
 *          one depended on position in the string, is what produced the malformed identifier
 *          log line (GHT-17). Log formatting now lives in SSOProcessingContext.describe().
 *
 * [GHT-18] TOKEN_REFERENCE kept as a JSON key ONLY. It was being concatenated into log lines as
 *          if it were a label, producing output like "tokenId=123token_referenceabc-def".
 *
 * [GHT-03] ADDED CONTEXT_OTP_TOKEN_VENDOR, CONTEXT_OLD_OTP_TOKEN_SERIAL_NO and
 *          CONTEXT_NEW_OTP_TOKEN_SERIAL_NO so the audit record states what was replaced with
 *          what. OTP_TOKEN_VENDOR is written by the CR and was audited nowhere.
 *
 * [GHT-24] ADDED DEFAULT_COMPANY_ID. resolveAuditCompanyId was falling back to DEFAULT_USER_ID
 *          for a company identifier. It works today only because both happen to be "0".
 *
 * [GHT-35] CONTEXT_FIELDS changed from protected to public (protected is unreachable in a final
 *          class with a private constructor) and wrapped in unmodifiableList.
 *
 * [GHT-05] ADDED MAX_AUDIT_CONTEXT_LENGTH. See SSOAuditProcessor for the guard.
 *
 * [GHT-32] REMOVED unused constants: OLD_TOKEN_SERIAL_NO (no such key is sent), CHARGE_TYPE,
 *          REMARKS, OTP_TOKEN_CHARGE_TYPE. Correction to the review: MODIFIED and OTP_TOKEN_ID
 *          ARE referenced by SSOAuditProcessor and have been kept.
 */
public final class SSOConstants {

    private SSOConstants() {
    }

    public static final String GUID = "guid";

    public static final String PRIMARY_GROUP_NAME = "primary_group_name";
    public static final String PRIMARY_LOGIN_ID = "primary_login_id";
    public static final String PRIMARY_MAKER_LOGIN_ID = "primary_maker_login_id";
    public static final String PRIMARY_CHECKER_LOGIN_ID = "primary_checker_login_id";
    public static final String PRIMARY_COUNTRY = "primary_country";
    public static final String PRIMARY_LAST_MODIFIED_TIME = "primary_last_modified_time";

    public static final String NEW_TOKEN_SERIAL_NO = "new_token_serial_no";

    public static final String PARTICIPATING_GROUP_ID = "participating_group_id";
    public static final String PARTICIPATING_GROUP_NAME = "participating_group_name";
    public static final String PARTICIPATING_COUNTRY = "participating_country";
    public static final String PARTICIPANT_USER_ID = "participant_user_id";
    public static final String PARTICIPANT_LOGIN_ID = "participant_login_id";

    public static final String TOKEN_VENDOR = "token_vendor";

    /** [GHT-18] JSON key and BulkReference column name only. Never use as a log label. */
    public static final String TOKEN_ID = "token_id";

    /** [GHT-18] JSON key only. Never use as a log label. */
    public static final String TOKEN_REFERENCE = "token_reference";

    public static final String OTP_TOKEN_ID = "otp_token_id";

    public static final String LOGIN_ID = "LOGIN_ID";
    public static final String COMPANY_ID = "COMPANY_ID";
    public static final String USER_ID = "USER_ID";
    public static final String MODIFIED = "MODIFIED";
    public static final String TNX_ID = "TNX_ID";
    public static final String SEQ = "SEQ";
    public static final String SEQ_AUDIT = "SEQ_AUDIT";
    public static final String SEQ_AUDIT_ITEM = "SEQ_AUDIT_ITEM";

    public static final String CONTEXT_ACTION = "Action";
    public static final String CONTEXT_DATE = "Date";
    public static final String CONTEXT_GROUP_ID = "Group ID";
    public static final String CONTEXT_IP_ADDRESS = "IP Address";
    public static final String CONTEXT_RESULT = "Result";
    public static final String CONTEXT_TYPE = "Type";
    public static final String CONTEXT_USER = "User";
    public static final String CONTEXT_REQUESTED_USER_ID = "Requested User ID";
    public static final String CONTEXT_REQUESTED_GROUP_ID = "Requested Group ID";
    public static final String CONTEXT_ACCESS_COUNTER = "access_counter";
    public static final String CONTEXT_FIRST_NAME = "FIRST_NAME";
    public static final String CONTEXT_ACTV_FLAG = "ACTV_FLAG";
    public static final String CONTEXT_MAKER_DTTM = "MAKER_DTTM";
    public static final String CONTEXT_OTP_TOKEN_ASSIGNED_BY = "OTP_TOKEN_ASSIGNED_BY";
    public static final String CONTEXT_OTP_TOKEN_CHARGE_TYPE = "OTP_TOKEN_CHARGE_TYPE";
    public static final String CONTEXT_REMARKS = "REMARKS";
    public static final String CONTEXT_LANGUAGE = "LANGUAGE";
    public static final String CONTEXT_LEGAL_NO = "legal_no";
    public static final String CONTEXT_LOGIN_ATTEMPTS = "login_attempts";
    public static final String CONTEXT_LAST_LOGIN = "LAST_LOGIN";
    public static final String CONTEXT_ONE_FA_LAST_LOGIN = "ONE_FA_LAST_LOGIN";
    public static final String CONTEXT_PREVIOUS_LOGIN_TIME = "PREVIOUS_LOGIN_TIME";
    public static final String CONTEXT_TERMS_CONDS_ACCEPT_DATE = "TERMS_CONDS_ACCEPT_DATE";
    public static final String CONTEXT_TNX_TYPE_CODE = "TNX_TYPE_CODE";
    public static final String CONTEXT_OTP_TOKEN_PRIVATE = "OTP_TOKEN_PRIVATE";
    public static final String CONTEXT_OTP_TOKEN_TYPE = "otp_token_type";
    public static final String CONTEXT_MAKER_ID = "MAKER_ID";
    public static final String CONTEXT_CREATOR_LOGIN = "CREATOR_LOGIN";
    public static final String CONTEXT_CHECKER_DTTM = "CHECKER_DTTM";
    public static final String CONTEXT_CREATED = "CREATED";
    public static final String CONTEXT_OTP_TOKEN_REMARKS = "otp_token_remarks";
    public static final String CONTEXT_COMPANY_TYPE = "COMPANY_TYPE";
    public static final String CONTEXT_OTP_TOKEN_REFERENCE_NO = "otp_token_reference_no";
    public static final String CONTEXT_GROUP_ABBV_NAME = "group_abbv_name";
    public static final String CONTEXT_CHECKER_ID = "CHECKER_ID";
    public static final String CONTEXT_CREATOR_ID = "CREATOR_ID";
    public static final String CONTEXT_PHONE = "PHONE";
    public static final String CONTEXT_ADDRESS_LINE_2 = "ADDRESS_LINE_2";
    public static final String CONTEXT_OTP_TOKEN_ASSIGNED_DATE = "otp_token_assigned_date";
    public static final String CONTEXT_EXISTING_ROLES = "existing_roles";
    public static final String CONTEXT_ADDRESS_LINE_1 = "ADDRESS_LINE_1";
    public static final String CONTEXT_LEGAL_TYPE = "legal_type";
    public static final String CONTEXT_COUNTRY = "COUNTRY";
    public static final String CONTEXT_FAX = "FAX";
    public static final String CONTEXT_COMPANY_ABBV_NAME = "COMPANY_ABBV_NAME";
    public static final String CONTEXT_LAST_NAME = "LAST_NAME";
    public static final String CONTEXT_CUR_CODE = "CUR_CODE";
    public static final String CONTEXT_OLD_DEFAULT_ENTITY_MC = "old_default_entity_mc";
    public static final String CONTEXT_OTP_TOKEN_ID = "otp_token_id";
    public static final String CONTEXT_MAKER_USER_NAME = "MAKER_USER_NAME";
    public static final String CONTEXT_EMAIL = "EMAIL";
    public static final String CONTEXT_GROUP_RECORD = "group_record";
    public static final String CONTEXT_NAME = "NAME";
    public static final String CONTEXT_ROLE = "role";
    public static final String CONTEXT_TIME_ZONE = "TIME_ZONE";
    public static final String CONTEXT_OTP_TOKEN_SERIAL_NO = "otp_token_serial_no";
    public static final String CONTEXT_DOM = "DOM";
    public static final String CONTEXT_BRCH_CODE = "brch_code";
    public static final String CONTEXT_LEGAL_COUNTRY = "legal_country";
    public static final String CONTEXT_IS_API = "IS_API";
    public static final String CONTEXT_CREATOR_COMPANY = "CREATOR_COMPANY";
    public static final String CONTEXT_OTP_TOKEN_PROMOTE_GLOBAL = "otp_token_promote_global";
    public static final String CONTEXT_OTP_TOKEN_STATUS = "otp_token_status";
    public static final String CONTEXT_RETURN_COMMENTS = "RETURN_COMMENTS";

    /**
     * [GHT-03] Token vendor is written by SSOMessageConsumer.updateUserDetails but was absent
     * from the audit on every path. Added to the BAU snapshot below.
     */
    public static final String CONTEXT_OTP_TOKEN_VENDOR = "otp_token_vendor";

    /**
     * [GHT-03] Explicit before/after serial lines in the CR-specific audit block. The BAU
     * snapshot reads otp_token_serial_no off the in-memory GTPUser, which on the success path
     * already holds the NEW value, so the old serial was recoverable from nowhere.
     */
    public static final String CONTEXT_OLD_OTP_TOKEN_SERIAL_NO = "Old Token Serial No";
    public static final String CONTEXT_NEW_OTP_TOKEN_SERIAL_NO = "New Token Serial No";

    public static final String ACTION_CODE = "GlobalHardTokenReplace";
    public static final String RESULT_SUCCESS_HT = "HT";
    public static final String RESULT_FAILURE_HF = "HF";

    public static final String DEFAULT_USER_ID = "0";

    /** [GHT-24] Distinct from DEFAULT_USER_ID so changing one cannot silently corrupt the other. */
    public static final String DEFAULT_COMPANY_ID = "0";

    /**
     * TODO [GHT-14] Every row this interface writes records IP as IPv6 loopback, which implies a
     * local action for a change that originated in an external SSO system. Replace with a source
     * system identifier, or obtain written bank sign-off on the placeholder.
     */
    public static final String DEFAULT_IP_ADDR = "0:0:0:0:0:0:0:1";

    public static final String AUDIT_TYPE = "N";
    public static final String MASTER_NO = "N";

    public static final String TNX_STAT_CODE = "TNX_STAT_CODE";

    public static final String GTP_AUDIT_SEQ = "GTP_AUDIT_SEQ";
    public static final String GTP_AUDIT_ITEM_SEQ = "GTP_AUDIT_ITEM_SEQ";

    /**
     * [GHT-05] Guard on the CONTEXT payload size. The BAU snapshot emits all 60 fields whether
     * populated or not, and free-text fields (REMARKS, RETURN_COMMENTS, otp_token_remarks,
     * existing_roles) are copied verbatim with no truncation, so the payload is unbounded.
     *
     * TODO [GHT-05] CONFIRM THE ACTUAL COLUMN DEFINITION of GTP_AUDIT_ITEM.CONTEXT before
     * accepting this value. If VARCHAR2(4000) this is correct. If it is a CLOB, raise the limit
     * and switch the bind in SSOAuditProcessor to setCharacterStream.
     */
    public static final int MAX_AUDIT_CONTEXT_LENGTH = 4000;

    /** [GHT-05] Appended when the context is truncated, so a shortened row is self-identifying. */
    public static final String CONTEXT_TRUNCATED_MARKER = "\n[CONTEXT TRUNCATED]";

    /** [GHT-10] Appended when the BAU snapshot could not be fully built. */
    public static final String CONTEXT_INCOMPLETE_MARKER = "\n[BAU CONTEXT INCOMPLETE]";

    /**
     * TODO [GHT-07] Table names are hardcoded here while getTokenIdFromSecurityMaster in the
     * consumer correctly resolves its table through TechnicalResourceProvider. Route these the
     * same way, or record in the solution document why the portal audit API could not be used.
     */
    public static final String INSERT_GTP_AUDIT_SQL = "INSERT INTO GTP_AUDIT "
            + "(AUDIT_ID, ACTION_CODE, COMPANY_ID, DATE_TIME, RESULT, TYPE, USER_ID, IP_ADDR) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    public static final String INSERT_GTP_AUDIT_ITEM_SQL = "INSERT INTO GTP_AUDIT_ITEM "
            + "(AUDIT_ID, ITEM_ID1, ITEM_ID2, TYPE, PRODUCT_CODE, RESULT, MASTER, CONTEXT, AUDIT_ITEM_ID, IP_ADDR) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /**
     * [GHT-06] Both sequence values fetched in one round trip instead of two separate
     * connection acquisitions. Original code took three connections per audit row.
     */
    public static final String SELECT_AUDIT_SEQUENCES_SQL = "SELECT " + GTP_AUDIT_SEQ + ".NEXTVAL AS " + SEQ_AUDIT
            + ", " + GTP_AUDIT_ITEM_SEQ + ".NEXTVAL AS " + SEQ_AUDIT_ITEM + " FROM DUAL";

    /**
     * [GHT-35] public, and unmodifiable. Was protected (unreachable) and element-mutable.
     * [GHT-03] CONTEXT_OTP_TOKEN_VENDOR added.
     */
    public static final List<String> CONTEXT_FIELDS = Collections.unmodifiableList(Arrays.asList(
            CONTEXT_ACCESS_COUNTER, CONTEXT_FIRST_NAME,
            CONTEXT_ACTV_FLAG, CONTEXT_MAKER_DTTM, CONTEXT_OTP_TOKEN_ASSIGNED_BY, CONTEXT_OTP_TOKEN_CHARGE_TYPE,
            CONTEXT_REMARKS, CONTEXT_LANGUAGE, CONTEXT_LEGAL_NO, CONTEXT_LOGIN_ATTEMPTS, CONTEXT_LAST_LOGIN,
            CONTEXT_ONE_FA_LAST_LOGIN, CONTEXT_PREVIOUS_LOGIN_TIME, CONTEXT_TERMS_CONDS_ACCEPT_DATE, MODIFIED,
            CONTEXT_TNX_TYPE_CODE, CONTEXT_OTP_TOKEN_PRIVATE, CONTEXT_OTP_TOKEN_TYPE, CONTEXT_MAKER_ID,
            CONTEXT_CREATOR_LOGIN, CONTEXT_CHECKER_DTTM, CONTEXT_CREATED, CONTEXT_OTP_TOKEN_REMARKS, TNX_ID,
            CONTEXT_COMPANY_TYPE, CONTEXT_OTP_TOKEN_REFERENCE_NO, COMPANY_ID,
            CONTEXT_GROUP_ABBV_NAME, CONTEXT_CHECKER_ID, CONTEXT_CREATOR_ID, CONTEXT_PHONE, CONTEXT_ADDRESS_LINE_2,
            CONTEXT_OTP_TOKEN_ASSIGNED_DATE, CONTEXT_EXISTING_ROLES, CONTEXT_ADDRESS_LINE_1, CONTEXT_LEGAL_TYPE,
            CONTEXT_COUNTRY, CONTEXT_FAX, CONTEXT_COMPANY_ABBV_NAME, CONTEXT_LAST_NAME, CONTEXT_CUR_CODE,
            CONTEXT_OLD_DEFAULT_ENTITY_MC, CONTEXT_OTP_TOKEN_ID, CONTEXT_MAKER_USER_NAME, CONTEXT_EMAIL,
            TNX_STAT_CODE, CONTEXT_GROUP_RECORD, CONTEXT_NAME, CONTEXT_ROLE, CONTEXT_TIME_ZONE, LOGIN_ID, USER_ID,
            CONTEXT_OTP_TOKEN_SERIAL_NO, CONTEXT_OTP_TOKEN_VENDOR, CONTEXT_DOM, CONTEXT_BRCH_CODE,
            CONTEXT_LEGAL_COUNTRY, CONTEXT_CREATOR_COMPANY, CONTEXT_OTP_TOKEN_PROMOTE_GLOBAL,
            CONTEXT_OTP_TOKEN_STATUS, CONTEXT_RETURN_COMMENTS));
}
