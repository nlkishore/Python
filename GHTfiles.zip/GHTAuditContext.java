package com.misys.portal.uob.interfaces.incoming;

/**
 * CR-specific audit block for GlobalHardTokenReplace, appended to the GTP_AUDIT_ITEM CONTEXT
 * payload after the header and the BAU snapshot.
 *
 * REVIEW CHANGES IN THIS FILE
 *
 * [GHT-03] ADDED oldTokenSerialNo, newTokenSerialNo and tokenVendor.
 *
 *          The BAU snapshot reads otp_token_serial_no off the in-memory GTPUser. On the success
 *          path the audit is written AFTER updateUserDetails, so that object already holds the
 *          new value, and ITEM_ID2 holds the new value too. The old serial was therefore
 *          recorded nowhere on the path that matters, and a completed replacement could not be
 *          reconstructed from its own audit row. otp_token_vendor is written by the CR and was
 *          absent from every path.
 *
 *          Recording both explicitly here also removes the dependency on WHEN the audit is
 *          called relative to the update, which is what made the failure-path value
 *          indeterminate (setPerm mutates the user object in memory before updateUser commits,
 *          so a failure between the two produced a context showing the new serial against a
 *          change that never persisted).
 *
 * [GHT-28] toString() replaced by an explicit buildContext(). The output of this method is
 *          PERSISTED into the CONTEXT column. Leaving it on toString() meant any future edit
 *          made for debugging would silently change stored audit data. toString() now delegates
 *          and is marked as not-for-persistence.
 *
 * [GHT-28] Getters added so the fields can be asserted individually in a unit test. The class
 *          was previously write-only.
 *
 * TODO [GHT-28] Confirm with the bank whether any existing report or extract parses the CONTEXT
 * column for GlobalHardTokenReplace. If so, adding lines changes a consumed format and the new
 * lines must be agreed before release.
 */
public final class GHTAuditContext {

    private String tokenReplacedCountry;
    private String tokenReplacedUserOrGroup;
    private String tokenReplacementRequestedBy;
    private String tokenReplacementApprovedBy;
    private String tokenReplacementApprovedDate;

    // [GHT-03] new fields
    private String oldTokenSerialNo;
    private String newTokenSerialNo;
    private String tokenVendor;

    public void setTokenReplacedCountry(String tokenReplacedCountry) {
        this.tokenReplacedCountry = tokenReplacedCountry;
    }

    public void setTokenReplacedUserOrGroup(String tokenReplacedUserOrGroup) {
        this.tokenReplacedUserOrGroup = tokenReplacedUserOrGroup;
    }

    public void setTokenReplacementRequestedBy(String tokenReplacementRequestedBy) {
        this.tokenReplacementRequestedBy = tokenReplacementRequestedBy;
    }

    public void setTokenReplacementApprovedBy(String tokenReplacementApprovedBy) {
        this.tokenReplacementApprovedBy = tokenReplacementApprovedBy;
    }

    public void setTokenReplacementApprovedDate(String tokenReplacementApprovedDate) {
        this.tokenReplacementApprovedDate = tokenReplacementApprovedDate;
    }

    // [GHT-03] new setters

    public void setOldTokenSerialNo(String oldTokenSerialNo) {
        this.oldTokenSerialNo = oldTokenSerialNo;
    }

    public void setNewTokenSerialNo(String newTokenSerialNo) {
        this.newTokenSerialNo = newTokenSerialNo;
    }

    public void setTokenVendor(String tokenVendor) {
        this.tokenVendor = tokenVendor;
    }

    // [GHT-28] getters added for testability

    public String getTokenReplacedCountry() {
        return tokenReplacedCountry;
    }

    public String getTokenReplacedUserOrGroup() {
        return tokenReplacedUserOrGroup;
    }

    public String getTokenReplacementRequestedBy() {
        return tokenReplacementRequestedBy;
    }

    public String getTokenReplacementApprovedBy() {
        return tokenReplacementApprovedBy;
    }

    public String getTokenReplacementApprovedDate() {
        return tokenReplacementApprovedDate;
    }

    public String getOldTokenSerialNo() {
        return oldTokenSerialNo;
    }

    public String getNewTokenSerialNo() {
        return newTokenSerialNo;
    }

    public String getTokenVendor() {
        return tokenVendor;
    }

    /**
     * [GHT-28] The persisted audit payload. This is contract, not a debugging aid. Any change to
     * the emitted lines or their order changes what is stored in GTP_AUDIT_ITEM.CONTEXT and
     * needs the same sign-off as a schema change.
     */
    public String buildContext() {

        StringBuilder sb = new StringBuilder();

        sb.append("Token Replaced Country: ").append(SSOUtils.defaultValue(tokenReplacedCountry)).append("\n");

        sb.append("Token Replaced User/Group: ").append(SSOUtils.defaultValue(tokenReplacedUserOrGroup)).append("\n");

        // [GHT-03] before / after state of the replacement
        sb.append(SSOConstants.CONTEXT_OLD_OTP_TOKEN_SERIAL_NO).append(": ")
                .append(SSOUtils.defaultValue(oldTokenSerialNo)).append("\n");

        sb.append(SSOConstants.CONTEXT_NEW_OTP_TOKEN_SERIAL_NO).append(": ")
                .append(SSOUtils.defaultValue(newTokenSerialNo)).append("\n");

        sb.append("Token Vendor: ").append(SSOUtils.defaultValue(tokenVendor)).append("\n");

        sb.append("Token Replacement Requested By: ")
                .append(SSOUtils.defaultValue(tokenReplacementRequestedBy)).append("\n");

        sb.append("Token Replacement Approved By: ")
                .append(SSOUtils.defaultValue(tokenReplacementApprovedBy)).append("\n");

        sb.append("Token Replacement Approved Date: ")
                .append(SSOUtils.defaultValue(tokenReplacementApprovedDate));

        return sb.toString();
    }

    /**
     * [GHT-28] Debugging only. Do NOT use this value for persistence. Callers writing to the
     * audit must call buildContext().
     */
    @Override
    public String toString() {
        return buildContext();
    }
}
