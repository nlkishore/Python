package com.misys.portal.uob.interfaces.incoming;

import com.misys.portal.security.GTPUser;

/**
 * Shared helpers for the Global Hard Token Replace interface.
 *
 * REVIEW CHANGES IN THIS FILE
 *
 * [GHT-26] NEW CLASS. isBlank / isNullOrBlank / isNumeric / defaultValue were duplicated across
 *          SSOMessageConsumer, SSOValidationProcessor and SSOAuditProcessor, and the two
 *          isNullOrBlank implementations did NOT agree (the consumer's version omitted the
 *          "null" string check). Consolidated here so one input validates one way.
 *
 * [GHT-27] safeGetUserPermValue moved here from SSOMessageConsumer. SSOValidationProcessor was
 *          calling it statically on the consumer, which made the validator depend on the class
 *          that calls it.
 *
 * [GHT-12] maskSerial added so token serial numbers can be logged without exposing 2FA
 *          credential material in plaintext application logs.
 *
 * NOTE FOR DEV: if GEB already has an approved StringUtils / common helper for isBlank and
 * isNumeric, delete these and point at that instead. The intent is one implementation, not
 * necessarily this one.
 */
public final class SSOUtils {

    /**
     * [GHT-26] Upper bound on a numeric identifier so a caller cannot pass a digit string that
     * overflows the later Long.parseLong. Sized for a NUMBER(18) column.
     * TODO [GHT-26] confirm against the actual column precision for USER_ID / COMPANY_ID.
     */
    private static final int MAX_NUMERIC_LENGTH = 18;

    private SSOUtils() {
    }

    public static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty() || "null".equalsIgnoreCase(value.trim());
    }

    public static boolean isNumeric(String value) {

        if (isBlank(value)) {
            return false;
        }

        String trimmedValue = value.trim();

        // [GHT-26] length bound added. The original accepted digit strings of unbounded length,
        // which then overflowed when the same value reached JSONObject.getLong downstream.
        if (trimmedValue.length() > MAX_NUMERIC_LENGTH) {
            return false;
        }

        for (int i = 0; i < trimmedValue.length(); i++) {

            if (!Character.isDigit(trimmedValue.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    public static String defaultValue(String value) {
        return value == null ? "" : value;
    }

    /**
     * [GHT-27] Relocated unchanged from SSOMessageConsumer.safeGetUserPermValue.
     */
    public static String safeGetUserPermValue(GTPUser user, String fieldName) {

        if (user == null || fieldName == null || fieldName.trim().isEmpty()) {
            return null;
        }

        Object value = user.getPerm(fieldName);

        if (value instanceof String) {

            String stringValue = ((String) value).trim();

            return stringValue.isEmpty() ? null : stringValue;
        }

        return value == null ? null : value.toString().trim();
    }

    /**
     * [GHT-12] Masks a token serial number for logging, retaining the last four characters only.
     * The audit record still stores the full value; only the log line is masked.
     *
     * TODO [GHT-12] confirm the masking convention with the bank's security reviewer. Last-four
     * is the common default but UOB may mandate full suppression for hard token serials.
     */
    public static String maskSerial(String serialNo) {

        if (isBlank(serialNo)) {
            return "";
        }

        String trimmed = serialNo.trim();

        if (trimmed.length() <= 4) {
            return "****";
        }

        return "****" + trimmed.substring(trimmed.length() - 4);
    }
}
