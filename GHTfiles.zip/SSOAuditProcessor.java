package com.misys.portal.uob.interfaces.incoming;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;

import com.misys.portal.common.resources.BusinessCodes;
import com.misys.portal.common.tools.MQConstantUtil;
import com.misys.portal.common.tools.Utils;
import com.misys.portal.interfaces.core.InterfaceException;
import com.misys.portal.security.GTPUser;
import com.misys.portal.services.db.PoolBrokerService;

/**
 * REVIEW CHANGES IN THIS FILE
 *
 * [GHT-04] REMOVED the firstNonBlank fallback on ITEM_ID1. If participant_login_id arrived blank
 *          the audit row was written against the PRIMARY user, a different person in a different
 *          country, as the subject of the token replacement. The value is now validated upstream
 *          and a blank one fails here rather than resolving to another identity.
 *
 * [GHT-03] insertGlobalHardTokenAudit takes oldTokenSerialNo, and the CR audit block records the
 *          old serial, the new serial and the token vendor explicitly.
 *
 * [GHT-05] Context payload guarded against the column length.
 *
 * [GHT-06] Both sequences fetched in one round trip. Was two separate connection acquisitions
 *          plus the transaction connection: three per audit row.
 *          NOTE: the connection release pattern is UNCHANGED. Verified with the dev that
 *          commitTransaction only commits and the finally block is what releases, so
 *          beginTransaction / getConnection / commitTransaction / closeResources is correct and
 *          was never a double-release.
 *
 * [GHT-08] Explicit named binds. The original looped over a String[] with magic-number
 *          exceptions (i == 3 for the timestamp, i == 4 for the null product code) that had to
 *          stay in sync with column order inside SQL constants held in another class. Reordering
 *          a column compiled cleanly and corrupted every row thereafter.
 *
 * [GHT-09] One timestamp. DATE_TIME and the "Date" context line were built from two separate
 *          System.currentTimeMillis() calls, so an audit row disagreed with itself.
 *
 * [GHT-10] Partial BAU context is now marked in the payload, and the misleading warning is
 *          corrected. The old message claimed all fields would be blank; in reality a mid-loop
 *          failure left the already-populated entries in place and blanked the rest, and the row
 *          was written as though complete.
 *
 * [GHT-11] Rollback failure is logged, not thrown. It previously replaced the original exception,
 *          discarding the reason the insert failed in the one case where it matters most.
 *
 * [GHT-15] Numeric columns bound with setLong.
 *
 * [GHT-24] DEFAULT_COMPANY_ID used for the company fallback instead of DEFAULT_USER_ID.
 *
 * [GHT-26] Local isBlank / isNumeric / defaultValue removed in favour of SSOUtils.
 *
 * [GHT-37] Dead ResultSet local removed from insertAuditLine.
 */
public class SSOAuditProcessor {

    private static final Log LOG = LogFactory.getLog(SSOAuditProcessor.class);

    /**
     * [GHT-03] oldTokenSerialNo parameter added. It must be read by the caller BEFORE any
     * setPerm mutates the in-memory GTPUser, otherwise the value is whatever the flow last wrote
     * rather than the state that actually preceded the change.
     */
    public void insertGlobalHardTokenAudit(JSONObject jsonRequest, String resultCode, GTPUser user,
            String oldTokenSerialNo) throws InterfaceException {

        try {

            // [GHT-06] one round trip for both sequences
            long[] sequences = fetchAuditSequences();

            long auditId = sequences[0];
            long auditItemId = sequences[1];

            String companyId = resolveAuditCompanyId(user);

            // [GHT-04] no fallback to PRIMARY_LOGIN_ID
            String itemId1 = jsonRequest.optString(SSOConstants.PARTICIPANT_LOGIN_ID);

            if (SSOUtils.isBlank(itemId1)) {
                throw new InterfaceException(new IllegalStateException(
                        "Participating login id is blank. Refusing to write an audit row that would be "
                                + "attributed to a different identity."));
            }

            String itemId2 = jsonRequest.optString(SSOConstants.NEW_TOKEN_SERIAL_NO);

            // [GHT-09] ONE timestamp, used for both the column and the context line
            Timestamp auditTimestamp = new Timestamp(System.currentTimeMillis());

            String context = buildAuditContext(jsonRequest, resultCode, companyId, auditTimestamp, user,
                    oldTokenSerialNo);

            // [GHT-12] no serial in the log line
            LOG.info("Audit insert details: resultCode=" + resultCode + ", companyId=" + companyId
                    + ", itemId1=" + itemId1 + ", auditId=" + auditId);

            insertAuditLine(auditId, auditItemId, companyId, resultCode, itemId1, itemId2, context, auditTimestamp);

            LOG.info("GlobalHardTokenReplace audit inserted successfully. auditId=" + auditId
                    + ", resultCode=" + resultCode);

        } catch (InterfaceException e) {

            throw e;

        } catch (Exception e) {

            LOG.error("Error while inserting GlobalHardTokenReplace audit.", e);

            throw new InterfaceException(e);
        }
    }

    /**
     * [GHT-08] Explicit binds replacing the indexed loop with magic-number exceptions.
     * [GHT-11] Rollback failure logged rather than thrown over the original cause.
     * [GHT-15] Numeric columns bound as numerics.
     * [GHT-37] Dead ResultSet removed.
     *
     * Connection handling is intentionally unchanged: beginTransaction, getConnection, commit,
     * and release in finally. Confirmed correct against the GEB PoolBrokerService contract.
     */
    private void insertAuditLine(long auditId, long auditItemId, String companyId, String resultCode,
            String itemId1, String itemId2, String context, Timestamp auditTimestamp) throws InterfaceException {

        Connection con = null;
        PreparedStatement auditStmt = null;

        try {

            PoolBrokerService.beginTransaction();

            con = PoolBrokerService.getConnection();

            if (LOG.isDebugEnabled()) {
                LOG.debug("SSOAuditProcessor >>>> Inserting GTP_AUDIT. auditId=" + auditId);
            }

            auditStmt = con.prepareStatement(SSOConstants.INSERT_GTP_AUDIT_SQL);

            // TODO [GHT-15] confirm AUDIT_ID / COMPANY_ID / USER_ID are NUMBER columns. They are
            // sequence-driven so almost certainly are, but the original bound them as strings and
            // this changes the bind type.
            auditStmt.setLong(1, auditId);
            auditStmt.setString(2, SSOConstants.ACTION_CODE);
            auditStmt.setLong(3, Long.parseLong(companyId));
            auditStmt.setTimestamp(4, auditTimestamp);
            auditStmt.setString(5, resultCode);
            auditStmt.setString(6, SSOConstants.AUDIT_TYPE);
            auditStmt.setLong(7, Long.parseLong(SSOConstants.DEFAULT_USER_ID));
            auditStmt.setString(8, SSOConstants.DEFAULT_IP_ADDR);

            auditStmt.executeUpdate();

            auditStmt.close();
            auditStmt = null;

            if (LOG.isDebugEnabled()) {
                LOG.debug("SSOAuditProcessor >>>> Inserting GTP_AUDIT_ITEM. auditItemId=" + auditItemId);
            }

            auditStmt = con.prepareStatement(SSOConstants.INSERT_GTP_AUDIT_ITEM_SQL);

            auditStmt.setLong(1, auditId);
            auditStmt.setString(2, itemId1);
            auditStmt.setString(3, itemId2);
            auditStmt.setString(4, BusinessCodes.N087_USER);
            auditStmt.setNull(5, java.sql.Types.VARCHAR);
            auditStmt.setString(6, resultCode);
            auditStmt.setString(7, SSOConstants.MASTER_NO);

            // TODO [GHT-05] if CONTEXT is a CLOB, switch this to setCharacterStream and raise
            // MAX_AUDIT_CONTEXT_LENGTH accordingly.
            auditStmt.setString(8, context);

            auditStmt.setLong(9, auditItemId);
            auditStmt.setString(10, SSOConstants.DEFAULT_IP_ADDR);

            auditStmt.executeUpdate();

            PoolBrokerService.commitTransaction();

        } catch (Exception e) {

            LOG.error("SSOAuditProcessor >>>> Error inserting audit data. auditId=" + auditId, e);

            try {

                PoolBrokerService.rollbackTransaction();

            } catch (Exception rollbackException) {

                // [GHT-11] logged, NOT thrown. Throwing here replaced 'e' and lost the reason the
                // insert failed, which is the more useful of the two.
                LOG.error("SSOAuditProcessor >>>> Rollback failed after audit insert failure. auditId="
                        + auditId, rollbackException);
            }

            throw new InterfaceException(e);

        } finally {

            Utils.closeResources(con, auditStmt, null);
        }
    }

    private String buildAuditContext(JSONObject jsonRequest, String resultCode, String auditCompanyId,
            Timestamp auditTimestamp, GTPUser user, String oldTokenSerialNo) {

        StringBuilder finalContext = new StringBuilder();

        finalContext.append(buildAuditHeaderContext(jsonRequest, resultCode, auditCompanyId, auditTimestamp));

        BauContextResult bauResult = buildExistingBAUContext(user);

        if (!SSOUtils.isBlank(bauResult.getContext())) {
            finalContext.append(bauResult.getContext().trim());
            finalContext.append("\n");
        }

        finalContext.append(buildGlobalHardTokenContext(jsonRequest, user, oldTokenSerialNo));

        // [GHT-10] a partially built snapshot is marked in the payload itself, so the row is
        // self-identifying rather than looking complete
        if (!bauResult.isComplete()) {
            finalContext.append(SSOConstants.CONTEXT_INCOMPLETE_MARKER);
        }

        return applyContextLengthGuard(finalContext.toString());
    }

    /**
     * [GHT-05] The BAU snapshot emits all 60 fields whether populated or not, and free-text
     * fields (REMARKS, RETURN_COMMENTS, otp_token_remarks, existing_roles) are copied verbatim,
     * so the payload has no natural upper bound. Without this guard a user with a long remarks
     * value or role list fails the insert with ORA-12899 / ORA-01461 in production, on exactly
     * the users who carry the most history, and never in SIT with thin test data.
     *
     * Truncation is deliberately from the END so the header and BAU block survive and the CR
     * block is the first thing lost. Reconsider the ordering if the bank prefers the reverse.
     *
     * TODO [GHT-05] CONFIRM THE COLUMN DEFINITION before accepting this.
     */
    private String applyContextLengthGuard(String context) {

        if (context == null || context.length() <= SSOConstants.MAX_AUDIT_CONTEXT_LENGTH) {
            return context;
        }

        LOG.warn("Audit context exceeds the configured maximum and will be truncated. length="
                + context.length() + ", max=" + SSOConstants.MAX_AUDIT_CONTEXT_LENGTH);

        int keep = SSOConstants.MAX_AUDIT_CONTEXT_LENGTH - SSOConstants.CONTEXT_TRUNCATED_MARKER.length();

        return context.substring(0, keep) + SSOConstants.CONTEXT_TRUNCATED_MARKER;
    }

    private String buildAuditHeaderContext(JSONObject jsonRequest, String resultCode, String auditCompanyId,
            Timestamp auditTimestamp) {

        StringBuilder sb = new StringBuilder();

        appendContextLine(sb, SSOConstants.CONTEXT_ACTION, SSOConstants.ACTION_CODE);
        appendContextLine(sb, SSOConstants.CONTEXT_DATE, auditTimestamp == null ? "" : auditTimestamp.toString());
        appendContextLine(sb, SSOConstants.CONTEXT_GROUP_ID, auditCompanyId);
        appendContextLine(sb, SSOConstants.CONTEXT_IP_ADDRESS, SSOConstants.DEFAULT_IP_ADDR);
        appendContextLine(sb, SSOConstants.CONTEXT_RESULT, resultCode);
        appendContextLine(sb, SSOConstants.CONTEXT_TYPE, SSOConstants.AUDIT_TYPE);
        appendContextLine(sb, SSOConstants.CONTEXT_USER, SSOConstants.DEFAULT_USER_ID);

        appendContextLine(sb, SSOConstants.CONTEXT_REQUESTED_USER_ID,
                jsonRequest.optString(SSOConstants.PARTICIPANT_USER_ID));

        appendContextLine(sb, SSOConstants.CONTEXT_REQUESTED_GROUP_ID,
                jsonRequest.optString(SSOConstants.PARTICIPATING_GROUP_ID));

        return sb.toString();
    }

    /**
     * [GHT-10] Returns completeness alongside the payload instead of swallowing a partial build.
     */
    private BauContextResult buildExistingBAUContext(GTPUser user) {

        Map<String, String> bauValues = initializeBauContextMap();

        boolean complete = true;

        try {

            populateBauUserContext(bauValues, user);

        } catch (Exception e) {

            complete = false;

            // [GHT-10] the original message said all fields would be blank. They are not: entries
            // populated before the failure are retained and the remainder stay blank.
            LOG.warn("Unable to fully build the BAU audit context. The snapshot is PARTIAL: fields "
                    + "populated before the failure are retained, the remainder are blank. The context "
                    + "will be marked incomplete.", e);
        }

        return new BauContextResult(buildContextFromMap(bauValues), complete);
    }

    private void populateBauUserContext(Map<String, String> bauValues, GTPUser user) {

        if (user == null) {
            return;
        }

        bauValues.put(SSOConstants.CONTEXT_ACCESS_COUNTER, SSOUtils.defaultValue(String.valueOf(user.getAccessCounter())));
        bauValues.put(SSOConstants.CONTEXT_FIRST_NAME, SSOUtils.defaultValue(user.getFirstName()));
        bauValues.put(SSOConstants.CONTEXT_ACTV_FLAG, SSOUtils.defaultValue(user.getActvFlag()));
        bauValues.put(SSOConstants.CONTEXT_MAKER_DTTM, getPermValue(user, SSOConstants.CONTEXT_MAKER_DTTM));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_ASSIGNED_BY,
                getPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_ASSIGNED_BY));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_CHARGE_TYPE,
                getPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_CHARGE_TYPE));
        bauValues.put(SSOConstants.CONTEXT_REMARKS, getPermValue(user, SSOConstants.CONTEXT_REMARKS));
        bauValues.put(SSOConstants.CONTEXT_LANGUAGE, SSOUtils.defaultValue(user.getLanguage()));
        bauValues.put(SSOConstants.CONTEXT_LEGAL_NO, getPermValue(user, GTPUser.LEGAL_NO));
        bauValues.put(SSOConstants.CONTEXT_LOGIN_ATTEMPTS, getPermValue(user, GTPUser.LOGIN_ATTEMPTS));
        bauValues.put(SSOConstants.CONTEXT_LAST_LOGIN,
                user.getLastLogin() == null ? "" : user.getLastLogin().toString());
        bauValues.put(SSOConstants.CONTEXT_ONE_FA_LAST_LOGIN, getPermValue(user, SSOConstants.CONTEXT_ONE_FA_LAST_LOGIN));
        bauValues.put(SSOConstants.CONTEXT_PREVIOUS_LOGIN_TIME, getPermValue(user, SSOConstants.CONTEXT_PREVIOUS_LOGIN_TIME));
        bauValues.put(SSOConstants.CONTEXT_TERMS_CONDS_ACCEPT_DATE,
                user.getTermsCondAcceptDate() == null ? "" : user.getTermsCondAcceptDate().toString());
        bauValues.put(SSOConstants.MODIFIED, user.getModified() == null ? "" : user.getModified().toString());
        bauValues.put(SSOConstants.CONTEXT_TNX_TYPE_CODE, getPermValue(user, SSOConstants.CONTEXT_TNX_TYPE_CODE));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_PRIVATE, getPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_PRIVATE));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_TYPE, getPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_TYPE));
        bauValues.put(SSOConstants.CONTEXT_MAKER_ID, getPermValue(user, SSOConstants.CONTEXT_MAKER_ID));
        bauValues.put(SSOConstants.CONTEXT_CREATOR_LOGIN, getPermValue(user, GTPUser.CREATOR_LOGIN));
        bauValues.put(SSOConstants.CONTEXT_CHECKER_DTTM, getPermValue(user, SSOConstants.CONTEXT_CHECKER_DTTM));
        bauValues.put(SSOConstants.CONTEXT_CREATED, user.getCreateDate() == null ? "" : user.getCreateDate().toString());
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_REMARKS, getPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_REMARKS));
        bauValues.put(SSOConstants.TNX_ID, getPermValue(user, SSOConstants.TNX_ID));
        bauValues.put(SSOConstants.CONTEXT_COMPANY_TYPE, SSOUtils.defaultValue(user.getCompanyType()));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_REFERENCE_NO,
                getPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_REFERENCE_NO));
        bauValues.put(SSOConstants.COMPANY_ID, String.valueOf(user.getCompanyId()));
        bauValues.put(SSOConstants.CONTEXT_GROUP_ABBV_NAME, getPermValue(user, SSOConstants.CONTEXT_GROUP_ABBV_NAME));
        bauValues.put(SSOConstants.CONTEXT_CHECKER_ID, getPermValue(user, SSOConstants.CONTEXT_CHECKER_ID));
        bauValues.put(SSOConstants.CONTEXT_CREATOR_ID, getPermValue(user, GTPUser.CREATOR_ID));
        bauValues.put(SSOConstants.CONTEXT_PHONE, SSOUtils.defaultValue(user.getPhone()));
        bauValues.put(SSOConstants.CONTEXT_ADDRESS_LINE_2, SSOUtils.defaultValue(user.getAddress_line_2()));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_ASSIGNED_DATE,
                getPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_ASSIGNED_DATE));
        bauValues.put(SSOConstants.CONTEXT_EXISTING_ROLES, getPermValue(user, SSOConstants.CONTEXT_EXISTING_ROLES));
        bauValues.put(SSOConstants.CONTEXT_ADDRESS_LINE_1, SSOUtils.defaultValue(user.getAddress_line_1()));
        bauValues.put(SSOConstants.CONTEXT_LEGAL_TYPE, getPermValue(user, GTPUser.LEGAL_TYPE));
        bauValues.put(SSOConstants.CONTEXT_COUNTRY, SSOUtils.defaultValue(user.getCountry()));
        bauValues.put(SSOConstants.CONTEXT_FAX, SSOUtils.defaultValue(user.getFax()));
        bauValues.put(SSOConstants.CONTEXT_COMPANY_ABBV_NAME, SSOUtils.defaultValue(user.getCompany_abbv_name()));
        bauValues.put(SSOConstants.CONTEXT_LAST_NAME, SSOUtils.defaultValue(user.getLastName()));
        bauValues.put(SSOConstants.CONTEXT_CUR_CODE, SSOUtils.defaultValue(user.getCur_code()));
        bauValues.put(SSOConstants.CONTEXT_OLD_DEFAULT_ENTITY_MC,
                getPermValue(user, SSOConstants.CONTEXT_OLD_DEFAULT_ENTITY_MC));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_ID, getPermValue(user, SSOConstants.OTP_TOKEN_ID));
        bauValues.put(SSOConstants.CONTEXT_MAKER_USER_NAME, getPermValue(user, SSOConstants.CONTEXT_MAKER_USER_NAME));
        bauValues.put(SSOConstants.CONTEXT_EMAIL, SSOUtils.defaultValue(user.getEmail()));
        bauValues.put(SSOConstants.TNX_STAT_CODE, getPermValue(user, SSOConstants.TNX_STAT_CODE));
        bauValues.put(SSOConstants.CONTEXT_GROUP_RECORD, getPermValue(user, SSOConstants.CONTEXT_GROUP_RECORD));

        // TODO [GHT-25] GTPUser.getName() returns the Turbine LOGIN name, so NAME and LOGIN_ID
        // below both carry the login id and the user's actual name is never audited. Compare
        // against a BAU audit row generated through the portal UI and correct the source for
        // NAME if the two do not match.
        bauValues.put(SSOConstants.CONTEXT_NAME, SSOUtils.defaultValue(user.getName()));

        bauValues.put(SSOConstants.CONTEXT_ROLE, getPermValue(user, SSOConstants.CONTEXT_ROLE));
        bauValues.put(SSOConstants.CONTEXT_TIME_ZONE, SSOUtils.defaultValue(user.getTimeZone()));
        bauValues.put(SSOConstants.LOGIN_ID, SSOUtils.defaultValue(user.getName()));
        bauValues.put(SSOConstants.USER_ID, SSOUtils.defaultValue(user.getIdAsString()));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_SERIAL_NO, getPermValue(user, MQConstantUtil.OTP_TOKEN_SERIAL_NO));

        // [GHT-03] token vendor is written by the CR and was audited nowhere
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_VENDOR, getPermValue(user, MQConstantUtil.OTP_TOKEN_VENDOR));

        bauValues.put(SSOConstants.CONTEXT_DOM, SSOUtils.defaultValue(user.getDom()));
        bauValues.put(SSOConstants.CONTEXT_BRCH_CODE, getPermValue(user, SSOConstants.CONTEXT_BRCH_CODE));
        bauValues.put(SSOConstants.CONTEXT_LEGAL_COUNTRY, getPermValue(user, GTPUser.LEGAL_COUNTRY));
        bauValues.put(SSOConstants.CONTEXT_CREATOR_COMPANY, getPermValue(user, GTPUser.CREATOR_COMPANY));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_PROMOTE_GLOBAL,
                getPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_PROMOTE_GLOBAL));
        bauValues.put(SSOConstants.CONTEXT_OTP_TOKEN_STATUS, getPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_STATUS));
        bauValues.put(SSOConstants.CONTEXT_RETURN_COMMENTS, getPermValue(user, SSOConstants.CONTEXT_RETURN_COMMENTS));
    }

    private Map<String, String> initializeBauContextMap() {

        Map<String, String> bauValues = new LinkedHashMap<String, String>();

        for (String fieldName : SSOConstants.CONTEXT_FIELDS) {
            bauValues.put(fieldName, "");
        }

        return bauValues;
    }

    private String buildContextFromMap(Map<String, String> bauValues) {

        StringBuilder context = new StringBuilder();

        for (String fieldName : SSOConstants.CONTEXT_FIELDS) {
            appendContextLine(context, fieldName, bauValues.get(fieldName));
        }

        return context.toString();
    }

    /**
     * [GHT-03] The CR-specific block now carries the before and after serial and the vendor, so a
     * completed replacement can be reconstructed from its own audit row without diffing against
     * a previous one.
     *
     * [GHT-28] buildContext() rather than toString().
     */
    private String buildGlobalHardTokenContext(JSONObject jsonRequest, GTPUser user, String oldTokenSerialNo) {

        GHTAuditContext context = new GHTAuditContext();

        context.setTokenReplacedCountry(jsonRequest.optString(SSOConstants.PARTICIPATING_COUNTRY));

        context.setTokenReplacedUserOrGroup(buildUserGroupDisplay(jsonRequest));

        context.setOldTokenSerialNo(SSOUtils.defaultValue(oldTokenSerialNo));

        context.setNewTokenSerialNo(jsonRequest.optString(SSOConstants.NEW_TOKEN_SERIAL_NO));

        context.setTokenVendor(jsonRequest.optString(SSOConstants.TOKEN_VENDOR));

        context.setTokenReplacementRequestedBy(jsonRequest.optString(SSOConstants.PRIMARY_MAKER_LOGIN_ID));

        context.setTokenReplacementApprovedBy(jsonRequest.optString(SSOConstants.PRIMARY_CHECKER_LOGIN_ID));

        context.setTokenReplacementApprovedDate(jsonRequest.optString(SSOConstants.PRIMARY_LAST_MODIFIED_TIME));

        return context.buildContext();
    }

    private String buildUserGroupDisplay(JSONObject jsonRequest) {

        String user = jsonRequest.optString(SSOConstants.PRIMARY_LOGIN_ID);
        String group = jsonRequest.optString(SSOConstants.PRIMARY_GROUP_NAME);

        if (!SSOUtils.isBlank(user) && !SSOUtils.isBlank(group)) {
            return user + " / " + group;
        }

        if (!SSOUtils.isBlank(user)) {
            return user;
        }

        return SSOUtils.defaultValue(group);
    }

    /**
     * [GHT-06] Both NEXTVAL values in a single statement on a single connection. The original
     * called fetchSequence twice, each acquiring and releasing its own connection, giving three
     * connection acquisitions per audit row.
     */
    private long[] fetchAuditSequences() throws InterfaceException {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {

            con = PoolBrokerService.getConnection();

            stmt = con.prepareStatement(SSOConstants.SELECT_AUDIT_SEQUENCES_SQL);

            rs = stmt.executeQuery();

            if (!rs.next()) {
                throw new InterfaceException(new IllegalStateException(
                        "No rows returned when fetching audit sequences."));
            }

            return new long[] { rs.getLong(SSOConstants.SEQ_AUDIT), rs.getLong(SSOConstants.SEQ_AUDIT_ITEM) };

        } catch (SQLException e) {

            LOG.error("SQL error while fetching audit sequences.", e);

            throw new InterfaceException(e);

        } catch (InterfaceException e) {

            throw e;

        } catch (Exception e) {

            LOG.error("Unexpected error while fetching audit sequences.", e);

            throw new InterfaceException(e);

        } finally {

            Utils.closeResources(con, stmt, rs);
        }
    }

    private void appendContextLine(StringBuilder context, String fieldName, String fieldValue) {
        context.append(fieldName).append(": ").append(SSOUtils.defaultValue(fieldValue)).append("\n");
    }

    /**
     * [GHT-24] Falls back to DEFAULT_COMPANY_ID, not DEFAULT_USER_ID. The original worked only
     * because both constants happened to be "0"; changing DEFAULT_USER_ID would have silently
     * corrupted the audit company attribution.
     */
    private String resolveAuditCompanyId(GTPUser user) {

        if (user != null) {

            String companyId = String.valueOf(user.getCompanyId());

            if (SSOUtils.isNumeric(companyId)) {
                return companyId;
            }
        }

        LOG.warn("Unable to resolve a valid company id from the user object. Using default company id "
                + SSOConstants.DEFAULT_COMPANY_ID + ".");

        return SSOConstants.DEFAULT_COMPANY_ID;
    }

    private String getPermValue(GTPUser user, String key) {

        if (user == null) {
            return "";
        }

        Object value = user.getPerm(key);

        return value == null ? "" : value.toString();
    }

    /**
     * [GHT-10] Carries whether the BAU snapshot was fully built, so the caller can mark a partial
     * payload instead of writing it as though complete.
     */
    private static final class BauContextResult {

        private final String context;
        private final boolean complete;

        private BauContextResult(String context, boolean complete) {
            this.context = context;
            this.complete = complete;
        }

        private String getContext() {
            return context;
        }

        private boolean isComplete() {
            return complete;
        }
    }
}
