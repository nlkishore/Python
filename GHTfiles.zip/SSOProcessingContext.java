package com.misys.portal.uob.interfaces.incoming;

/**
 * REVIEW CHANGES IN THIS FILE
 *
 * [GHT-34] REMOVED the jsonRequest field and getJsonRequest(). The field made the "context" hold
 *          a mutable JSONObject, so the object was final in name only and not a stable snapshot.
 *          Nothing called the getter anyway, because the consumer passed jsonRequest alongside
 *          the context to every method.
 *
 * [GHT-17] ADDED describe(). The malformed identifier log line came from hand-concatenating
 *          positional log-fragment constants in the wrong order, which emitted the company id
 *          before its own label:
 *
 *              SSO token replace identifiers: , userId=123loginId=ABC456, companyId=, groupAbbv=XYZ
 *
 *          Formatting now lives on the object that owns the values, so there is one place to get
 *          it wrong instead of one per call site.
 *
 * [GHT-03] ADDED oldTokenSerialNo. Captured once when the user is loaded, before any setPerm
 *          mutates the in-memory GTPUser, so every audit path has a reliable before-value
 *          regardless of where the flow failed.
 */
public class SSOProcessingContext {

    private final String loginId;
    private final String userId;
    private final String companyId;
    private final String groupAbbv;
    private final String participatingCountry;
    private final String newTokenSerialNo;

    // [GHT-03] state captured before the replacement runs
    private final String oldTokenSerialNo;

    public SSOProcessingContext(String loginId, String userId, String companyId, String groupAbbv,
            String participatingCountry, String newTokenSerialNo, String oldTokenSerialNo) {

        this.loginId = loginId;
        this.userId = userId;
        this.companyId = companyId;
        this.groupAbbv = groupAbbv;
        this.participatingCountry = participatingCountry;
        this.newTokenSerialNo = newTokenSerialNo;
        this.oldTokenSerialNo = oldTokenSerialNo;
    }

    public String getLoginId() {
        return loginId;
    }

    public String getUserId() {
        return userId;
    }

    public String getCompanyId() {
        return companyId;
    }

    public String getGroupAbbv() {
        return groupAbbv;
    }

    public String getParticipatingCountry() {
        return participatingCountry;
    }

    public String getNewTokenSerialNo() {
        return newTokenSerialNo;
    }

    public String getOldTokenSerialNo() {
        return oldTokenSerialNo;
    }

    /**
     * [GHT-17][GHT-18] Single formatter for the identifier block used in every log line for this
     * interface. Replaces LOGIN_ID_START / LOGIN_ID_PARAM / USER_ID_PARAM / COMPANY_ID_PARAM /
     * GROUP_ABBV_PARAM, which had to be selected by position in the target string.
     *
     * [GHT-12] Deliberately carries no serial number. Serials are 2FA credential material and are
     * masked at the call site where they are genuinely needed.
     */
    public String describe() {

        return "userId=" + SSOUtils.defaultValue(userId)
                + ", loginId=" + SSOUtils.defaultValue(loginId)
                + ", companyId=" + SSOUtils.defaultValue(companyId)
                + ", groupAbbv=" + SSOUtils.defaultValue(groupAbbv);
    }
}
