package com.misys.portal.uob.interfaces.incoming;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;

import com.misys.portal.common.resources.BusinessCodes;
import com.misys.portal.common.tools.MQConstantUtil;
import com.misys.portal.common.tracer.GTPException;
import com.misys.portal.security.GTPUser;
import com.misys.portal.security.GTPUserTnx;

/**
 * REVIEW CHANGES IN THIS FILE
 *
 * [GHT-19] validateFieldPresent now checks the VALUE, not just presence. The original called
 *          jsonRequest.has() only, so a field present as "" or JSON null passed validation.
 *          Fourteen fields were presence-checked and only three value-checked. This is also the
 *          precondition that made GHT-04 reachable: a blank participant_login_id passed
 *          validation and then silently resolved to the primary user in the audit row.
 *
 * [GHT-30] validateCompanyId error message corrected. It reported a user-id failure on a
 *          group-id validation, which would misdirect L3 during a live incident.
 *
 * [GHT-31] validateSecurityTokenDetails returns void. Every non-true path threw, so the boolean
 *          could only ever be true and the caller's guard was dead code.
 *
 * [GHT-26] Local isBlank / isNullOrBlank / isNumeric removed in favour of SSOUtils. isBlank and
 *          isNullOrBlank in this class were byte-identical, and the consumer's isNullOrBlank had
 *          DIFFERENT semantics, so the same input validated differently by class.
 *
 * [GHT-27] No longer calls SSOMessageConsumer.safeGetUserPermValue. That static call made the
 *          validator depend on the class that calls it.
 *
 * [GHT-12] GUID and token reference removed from exception messages. These are logged at ERROR
 *          and are 2FA credential material.
 *
 * [GHT-33] LOG.debug guarded with isDebugEnabled.
 */
public class SSOValidationProcessor {

    private static final Log LOG = LogFactory.getLog(SSOValidationProcessor.class);

    /**
     * [GHT-31] was: public boolean validateSecurityTokenDetails(...)
     */
    public void validateSecurityTokenDetails(GTPUser user, JSONObject jsonRequest, SSOProcessingContext context)
            throws GTPException {

        String guid = normalize(jsonRequest.optString(SSOConstants.GUID));

        if (SSOUtils.isBlank(guid)) {
            throwValidationException("GUID is missing. " + context.describe());
        }

        validateTokenReference(user, guid, context);
    }

    private void validateTokenReference(GTPUser user, String guid, SSOProcessingContext context) throws GTPException {

        // [GHT-27] was SSOMessageConsumer.safeGetUserPermValue
        String tokenReference = SSOUtils.safeGetUserPermValue(user, SSOConstants.CONTEXT_OTP_TOKEN_REFERENCE_NO);

        if (SSOUtils.isBlank(tokenReference)) {

            throwValidationException("Token reference is missing in the security master. " + context.describe());

        } else if (!matchesTokenReference(tokenReference, guid)) {

            // [GHT-12] neither value is included in the message. This is logged at ERROR.
            throwValidationException("GUID does not match the token_reference value in the security master. "
                    + context.describe());
        }
    }

    /**
     * TODO [GHT-29] The original comparison was case-sensitive equals. Confirm the case contract
     * for the GUID with the SSO source system. If the two systems do not guarantee identical
     * casing, a valid replacement is rejected. equalsIgnoreCase is applied here as the safer
     * default; revert to equals if the contract guarantees exact casing.
     */
    private boolean matchesTokenReference(String tokenReference, String guid) {
        return tokenReference.trim().equalsIgnoreCase(guid.trim());
    }

    public boolean hasPendingUserEdit(GTPUserTnx userTnx) {

        if (userTnx == null) {
            return false;
        }

        String tnxStatCode = userTnx.getTnxStatCode();

        boolean pendingUserEdit = BusinessCodes.N004_UNCONTROLLED.equals(tnxStatCode);

        // [GHT-33] guarded
        if (LOG.isDebugEnabled()) {
            LOG.debug("SSO token replace: pending user edit check. userId=" + userTnx.getIdAsString()
                    + ", tnxStatCode=" + tnxStatCode + ", pendingUserEdit=" + pendingUserEdit);
        }

        return pendingUserEdit;
    }

    public String getNewTokenSerialNo(JSONObject jsonRequest) {
        return jsonRequest.optString(SSOConstants.NEW_TOKEN_SERIAL_NO);
    }

    public String getTokenVendor(JSONObject jsonRequest) {
        return jsonRequest.optString(SSOConstants.TOKEN_VENDOR);
    }

    private void throwValidationException(String message) throws GTPException {

        LOG.error("SSO validation failed: " + message);

        // TODO [GHT-36] null is passed as the error code. Supply a defined code from the GEB
        // business/error catalogue so these failures map correctly in the trace layer.
        throw new GTPException(null, message);
    }

    private String normalize(String value) {

        if (SSOUtils.isBlank(value)) {
            return "";
        }

        return value.trim();
    }

    /**
     * [GHT-19] Presence AND value. Was: if (!jsonRequest.has(fieldKey)) throw.
     *
     * TODO [GHT-19] Confirm with the bank that every field below is genuinely mandatory and
     * never sent blank in a valid request. Tightening this rejects records that previously
     * passed, so it needs agreement before release. If any field is legitimately optional, split
     * it back out to a presence-only check.
     */
    private void validateFieldPresent(JSONObject jsonRequest, String fieldKey, String fieldDescription)
            throws GTPException {

        if (!jsonRequest.has(fieldKey)) {
            throwValidationException(fieldDescription + " field is missing in the JSON request.");
        }

        if (SSOUtils.isBlank(jsonRequest.optString(fieldKey))) {
            throwValidationException(fieldDescription + " field is present but blank in the JSON request.");
        }
    }

    public void validateJsonFieldPresence(JSONObject jsonRequest) throws GTPException {

        // Primary fields
        validateFieldPresent(jsonRequest, SSOConstants.PRIMARY_GROUP_NAME, "Primary group name");
        validateFieldPresent(jsonRequest, SSOConstants.PRIMARY_LOGIN_ID, "Primary login id");
        validateFieldPresent(jsonRequest, SSOConstants.PRIMARY_MAKER_LOGIN_ID, "Primary maker login id");
        validateFieldPresent(jsonRequest, SSOConstants.PRIMARY_CHECKER_LOGIN_ID, "Primary checker login id");
        validateFieldPresent(jsonRequest, SSOConstants.PRIMARY_COUNTRY, "Primary country");
        validateFieldPresent(jsonRequest, SSOConstants.PRIMARY_LAST_MODIFIED_TIME, "Primary last modified time");

        // Participating fields
        validateFieldPresent(jsonRequest, SSOConstants.PARTICIPANT_USER_ID, "Participating user id");
        validateFieldPresent(jsonRequest, SSOConstants.PARTICIPATING_GROUP_ID, "Participating group id");
        validateFieldPresent(jsonRequest, SSOConstants.PARTICIPANT_LOGIN_ID, "Participating login id");
        validateFieldPresent(jsonRequest, SSOConstants.PARTICIPATING_GROUP_NAME, "Participating group name");
        validateFieldPresent(jsonRequest, SSOConstants.PARTICIPATING_COUNTRY, "Participating country");

        // Token fields
        validateFieldPresent(jsonRequest, SSOConstants.GUID, "GUID");
        validateFieldPresent(jsonRequest, SSOConstants.NEW_TOKEN_SERIAL_NO, "New token serial number");
        validateFieldPresent(jsonRequest, SSOConstants.TOKEN_VENDOR, "Token vendor");
    }

    /**
     * [GHT-04] participatingLoginId added as a validated mandatory field. The audit row is keyed
     * on it, and SSOAuditProcessor previously fell back to the PRIMARY login id when it was
     * blank, writing the audit against a different identity.
     */
    public void validateMandatoryFields(String participatingUserId, String participatingCompanyId,
            String participatingLoginId, String newTokenSerialNo) throws GTPException {

        validateUserId(participatingUserId);

        validateCompanyId(participatingCompanyId);

        validateLoginId(participatingLoginId);

        validateNewTokenSerialNo(newTokenSerialNo);
    }

    private void validateUserId(String userId) throws GTPException {

        if (SSOUtils.isBlank(userId)) {

            throwValidationException("Participating user id cannot be null or blank.");

        } else if (!SSOUtils.isNumeric(userId)) {

            throwValidationException("Participating user id must contain only numbers. userId=" + userId);

        } else if ("0".equals(userId.trim())) {

            throwValidationException("Participating user id cannot be 0. userId=" + userId);
        }
    }

    private void validateCompanyId(String companyId) throws GTPException {

        if (SSOUtils.isBlank(companyId)) {

            throwValidationException("Participating group id cannot be null or blank.");

        } else if (!SSOUtils.isNumeric(companyId)) {

            throwValidationException("Participating group id must contain only numbers. groupId=" + companyId);

        } else if ("0".equals(companyId.trim())) {

            // [GHT-30] was: "Participating user id cannot be 0. userId=" + companyId
            throwValidationException("Participating group id cannot be 0. groupId=" + companyId);
        }
    }

    /**
     * [GHT-04] new
     */
    private void validateLoginId(String loginId) throws GTPException {

        if (SSOUtils.isBlank(loginId)) {
            throwValidationException("Participating login id cannot be null or blank. "
                    + "The audit record is keyed on this value.");
        }
    }

    private void validateNewTokenSerialNo(String newTokenSerialNo) throws GTPException {

        if (SSOUtils.isBlank(newTokenSerialNo)) {

            throwValidationException("New token serial number cannot be null or blank.");

        } else if (!SSOUtils.isNumeric(newTokenSerialNo)) {

            // [GHT-12] the serial is masked in the message
            throwValidationException("New token serial number must contain only numeric characters. "
                    + "newTokenSerialNo=" + SSOUtils.maskSerial(newTokenSerialNo));
        }
    }

    public boolean isNewSerialAlreadyAssignedToUser(GTPUser user, String newSerialNo) {

        // [GHT-27] routed through the shared accessor. This method previously called
        // user.getPerm() directly while the rest of the class used the helper.
        String currentSerialNo = SSOUtils.safeGetUserPermValue(user, MQConstantUtil.OTP_TOKEN_SERIAL_NO);

        if (SSOUtils.isBlank(currentSerialNo)) {
            return false;
        }

        return newSerialNo != null && newSerialNo.trim().equals(currentSerialNo.trim());
    }
}
