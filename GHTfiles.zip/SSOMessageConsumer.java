package com.misys.portal.uob.interfaces.incoming;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONObject;

import com.misys.portal.common.tools.MQConstantUtil;
import com.misys.portal.common.tools.Utils;
import com.misys.portal.common.tracer.GTPException;
import com.misys.portal.interfaces.core.InterfaceException;
import com.misys.portal.interfaces.core.event.AbstractObjectProducer;
import com.misys.portal.interfaces.core.event.ObjectConsumer;
import com.misys.portal.security.GTPCompany;
import com.misys.portal.security.GTPSecurity;
import com.misys.portal.security.GTPUser;
import com.misys.portal.security.GTPUserTnx;
import com.misys.portal.services.db.PoolBrokerService;
import com.misys.portal.common.resources.TechnicalResourceProvider;
import com.misys.portal.common.security.token.SecurityTokenManager;
import com.misys.portal.common.bulk.BulkReference;
import com.misys.portal.common.bulk.BulkReferencesSet;
import com.misys.portal.common.security.token.SecurityTokenImpl;
import org.apache.turbine.util.security.DataBackendException;
import org.apache.turbine.util.security.UnknownEntityException;

/**
 * REVIEW CHANGES IN THIS FILE
 *
 * [GHT-01] performTokenReplacement now compensates. The token master and the user record are
 *          committed independently. If the user update failed, the token master kept the new
 *          serial while the user record kept the old one, the user was locked out of 2FA, and
 *          the audit said the replacement failed. Nothing told L3 a data patch was needed.
 *          TODO: a single transaction boundary is the correct fix. See the note on that method.
 *
 * [GHT-02] The success audit no longer falls into the failure handler. Previously the HT insert
 *          sat inside the same try as the replacement, so a failing audit insert wrote an HF row
 *          for a replacement that had completed. Worse, on a deterministic failure (context too
 *          long, bad bind) the HF retry failed identically and was swallowed, leaving a
 *          successful credential change with NO audit row at all.
 *
 * [GHT-03] The old serial is captured once, when the user is loaded, before anything mutates the
 *          in-memory GTPUser, and carried on the context to every audit call.
 *
 * [GHT-13] getTokenIdFromSecurityMaster now detects multiple matching rows instead of silently
 *          taking the first.
 *
 * [GHT-15] Numeric column bound with setLong.
 *
 * [GHT-17] Identifier logging routed through SSOProcessingContext.describe().
 *
 * [GHT-20] All five LOG.error sites pass the exception. They previously concatenated
 *          e.getMessage(), so no stack trace was captured on an interface triaged from logs.
 *
 * [GHT-21] handle() no longer rethrows on an unparseable payload. See the note on that method.
 *
 * [GHT-22] buildProcessingContext no longer calls getLong.
 *
 * [GHT-23] updateGtpSecurityToken no longer takes tokenReference. It was used only in log lines.
 *
 * [GHT-26] Local isNullOrBlank removed. It disagreed with the validator's version.
 *
 * [GHT-27] safeGetUserPermValue moved to SSOUtils.
 */
public class SSOMessageConsumer extends AbstractObjectProducer implements ObjectConsumer {

    private static final Log LOG = LogFactory.getLog(SSOMessageConsumer.class);

    private final SSOAuditProcessor auditProcessor = new SSOAuditProcessor();

    private final SSOValidationProcessor validationProcessor = new SSOValidationProcessor();

    /**
     * [GHT-21] An unparseable payload is now logged and dropped rather than rethrown.
     *
     * Rethrowing InterfaceException here caused MQ to redeliver a message that can never parse,
     * which is an unbounded poison-message loop.
     *
     * TODO [GHT-21] CONFIRM THE INTENDED CONTRACT WITH THE BANK. Three options:
     *   (a) log and drop, as implemented here
     *   (b) route to a DLQ or error queue, if the interface framework provides one
     *   (c) rethrow, only if MQ is configured with a bounded redelivery count and a backout queue
     * Option (a) is the safe default but it means a malformed batch is lost silently. Do not
     * ship this without a decision recorded in the solution document.
     */
    @Override
    public void handle(Object object) throws InterfaceException {

        if (!(object instanceof String)) {
            return;
        }

        String message = (String) object;

        JSONArray ssoRequestArray;

        try {

            ssoRequestArray = new JSONArray(message.trim());

        } catch (Exception e) {

            // [GHT-20] exception passed, not concatenated
            LOG.error("SSO token replace: error parsing SSO message. Message dropped.", e);

            return;
        }

        if (ssoRequestArray.length() == 0) {
            return;
        }

        LOG.info("SSO token replace request received. count=" + ssoRequestArray.length());

        processSsoRequestArray(ssoRequestArray);
    }

    private void processSsoRequestArray(JSONArray ssoRequestArray) {

        for (int i = 0; i < ssoRequestArray.length(); i++) {

            JSONObject jsonRequest = ssoRequestArray.optJSONObject(i);

            if (jsonRequest == null || jsonRequest.length() == 0) {

                LOG.error("SSO token replace: invalid or empty JSON object at array index=" + i);

            } else {

                LOG.info("SSO token replace: processing record index=" + i);

                try {

                    validationProcessor.validateJsonFieldPresence(jsonRequest);

                    processSingleSSORequest(jsonRequest);

                } catch (Exception e) {

                    // [GHT-20] exception passed
                    LOG.error("SSO token replace failed. index=" + i
                            + ", loginId=" + jsonRequest.optString(SSOConstants.PARTICIPANT_LOGIN_ID)
                            + ", userId=" + jsonRequest.optString(SSOConstants.PARTICIPANT_USER_ID), e);
                }
            }
        }
    }

    private void processSingleSSORequest(JSONObject jsonRequest) throws InterfaceException {

        SSOProcessingContext context = null;

        GTPUser user = null;

        GTPUserTnx userTnx = null;

        boolean auditEligible = false;

        // [GHT-02] tracks whether the credential change actually completed, so a failure in the
        // audit insert cannot be mistaken for a failure of the replacement itself.
        boolean replacementCompleted = false;

        try {

            // [GHT-04] participating login id is now validated, because the audit row is keyed on it
            validationProcessor.validateMandatoryFields(
                    jsonRequest.optString(SSOConstants.PARTICIPANT_USER_ID),
                    jsonRequest.optString(SSOConstants.PARTICIPATING_GROUP_ID),
                    jsonRequest.optString(SSOConstants.PARTICIPANT_LOGIN_ID),
                    jsonRequest.optString(SSOConstants.NEW_TOKEN_SERIAL_NO));

            user = GTPSecurity.getUser(jsonRequest.optString(SSOConstants.PARTICIPANT_USER_ID).trim());

            // [GHT-03] read BEFORE anything mutates the user object
            String oldTokenSerialNo = SSOUtils.safeGetUserPermValue(user, MQConstantUtil.OTP_TOKEN_SERIAL_NO);

            context = buildProcessingContext(jsonRequest, oldTokenSerialNo);

            // [GHT-17] single formatter, correct ordering
            LOG.info("SSO token replace identifiers: " + context.describe());

            validationProcessor.validateSecurityTokenDetails(user, jsonRequest, context);

            GTPCompany company = GTPSecurity.getCompany(user.getCompany_abbv_name());

            if (company == null) {
                throwValidationException("Company not found. " + context.describe());
            }

            String newTokenSerialNo = validationProcessor.getNewTokenSerialNo(jsonRequest);

            if (validationProcessor.isNewSerialAlreadyAssignedToUser(user, newTokenSerialNo)) {

                // [GHT-12] serial masked
                LOG.info("SSO token replace: new token serial number is already assigned to the user. "
                        + "Skipping duplicate request. " + context.describe()
                        + ", newTokenSerialNo=" + SSOUtils.maskSerial(newTokenSerialNo));

                // TODO [GHT-16] This path writes NO audit row, while the pending-user-edit skip
                // below writes an HF row. The two skip paths are inconsistent. Confirm with the
                // bank whether a replayed request must leave a trace, and if so add an insert
                // here with a distinct result code so duplicates are separable from failures.
                return;
            }

            auditEligible = true;

            userTnx = getPendingUserTnx(user.getUserName(), company);

            if (userTnx != null && validationProcessor.hasPendingUserEdit(userTnx)) {

                LOG.info("SSO token replace: pending user edit found. Skipping token replacement. "
                        + context.describe());

                auditProcessor.insertGlobalHardTokenAudit(jsonRequest, SSOConstants.RESULT_FAILURE_HF, user,
                        context.getOldTokenSerialNo());

                return;
            }

            performTokenReplacement(jsonRequest, user, context);

            // [GHT-02] set BEFORE the audit call
            replacementCompleted = true;

            auditProcessor.insertGlobalHardTokenAudit(jsonRequest, SSOConstants.RESULT_SUCCESS_HT, user,
                    context.getOldTokenSerialNo());

        } catch (Exception e) {

            handleProcessingFailure(auditEligible, replacementCompleted, user, context, jsonRequest, e);

            throw new InterfaceException(e);
        }
    }

    private GTPUserTnx getPendingUserTnx(String loginId, GTPCompany company) throws DataBackendException {

        try {

            return GTPSecurity.getUserTnx(loginId, company);

        } catch (UnknownEntityException e) {

            LOG.info("SSO token replace: no pending user transaction found. loginId=" + loginId);

            return null;
        }
    }

    /**
     * [GHT-02] replacementCompleted added.
     *
     * When the replacement succeeded and only the audit insert failed, writing an HF row records
     * the opposite of what happened. Retrying the same insert with a different result code is
     * also futile when the cause is deterministic. This now raises a distinct, greppable error
     * so the missing audit row is handled as an operational exception rather than papered over.
     */
    private void handleProcessingFailure(boolean auditEligible, boolean replacementCompleted, GTPUser user,
            SSOProcessingContext context, JSONObject jsonRequest, Exception processingException) {

        if (replacementCompleted) {

            LOG.error("SSO token replace: TOKEN REPLACEMENT COMPLETED BUT AUDIT INSERT FAILED. "
                    + "A manual audit entry is required for this replacement. "
                    + (context != null ? context.describe() : ""), processingException);

            return;
        }

        if (!auditEligible) {

            // [GHT-20] exception passed
            LOG.error("Audit not inserted because request validation failed. "
                    + (context != null ? context.describe() : ""), processingException);

            return;
        }

        insertFailureAudit(user, context, jsonRequest);
    }

    private void insertFailureAudit(GTPUser user, SSOProcessingContext context, JSONObject jsonRequest) {

        try {

            auditProcessor.insertGlobalHardTokenAudit(jsonRequest, SSOConstants.RESULT_FAILURE_HF, user,
                    context == null ? "" : context.getOldTokenSerialNo());

        } catch (Exception auditException) {

            LOG.error("Failure audit insertion failed. " + (context != null ? context.describe() : ""),
                    auditException);
        }
    }

    /**
     * [GHT-22] getLong removed. It threw JSONException if the source system sent the user id as a
     * quoted string, and string coercion behaviour differs across org.json versions. The GEB
     * portal carries a modified json.jar, so relying on that behaviour couples this interface to
     * the jar version deployed in each environment. The value is numeric-validated upstream.
     */
    private SSOProcessingContext buildProcessingContext(JSONObject jsonRequest, String oldTokenSerialNo) {

        String participatingCountry = jsonRequest.optString(SSOConstants.PARTICIPATING_COUNTRY);

        String loginId = jsonRequest.optString(SSOConstants.PARTICIPANT_LOGIN_ID);

        String userId = jsonRequest.optString(SSOConstants.PARTICIPANT_USER_ID).trim();

        String companyId = jsonRequest.optString(SSOConstants.PARTICIPATING_GROUP_ID);

        String groupAbbv = jsonRequest.optString(SSOConstants.PARTICIPATING_GROUP_NAME);

        String newTokenSerialNo = jsonRequest.optString(SSOConstants.NEW_TOKEN_SERIAL_NO);

        return new SSOProcessingContext(loginId, userId, companyId, groupAbbv, participatingCountry,
                newTokenSerialNo, oldTokenSerialNo);
    }

    /**
     * [GHT-01] Compensating rollback added.
     *
     * TODO [GHT-01] THIS IS A MITIGATION, NOT THE FIX. The correct fix is a single transaction
     * spanning SecurityTokenManager.updateToken and GTPSecurity.updateUser. Confirm with the
     * framework owner whether PoolBrokerService.beginTransaction can enclose both calls; if it
     * can, replace this compensation with a real transaction boundary and delete the recovery
     * logging below. Compensation still has a window: if the compensating update also fails, the
     * data is inconsistent and the log line below is the only signal.
     */
    private void performTokenReplacement(JSONObject jsonRequest, GTPUser user, SSOProcessingContext context)
            throws GTPException, InterfaceException {

        String newSerial = validationProcessor.getNewTokenSerialNo(jsonRequest).trim();

        String tokenVendor = validationProcessor.getTokenVendor(jsonRequest).trim();

        String oldSerial = context.getOldTokenSerialNo();

        if (LOG.isDebugEnabled()) {
            LOG.debug("SSO token replace: resolving token id. " + context.describe());
        }

        String existingTokenId = getExistingTokenIdFromUser(user);

        if (SSOUtils.isBlank(existingTokenId)) {
            throw new GTPException("Unable to determine token id for user. " + context.describe());
        }

        // [GHT-23] tokenReference no longer passed. It was never written to the token, only logged.
        updateGtpSecurityToken(newSerial, existingTokenId);

        // [GHT-12] serial masked in the log line
        LOG.info("SSO token replace: token master updated. tokenId=" + existingTokenId
                + ", newSerial=" + SSOUtils.maskSerial(newSerial));

        try {

            updateUserDetails(user, newSerial, tokenVendor);

        } catch (GTPException userUpdateException) {

            // [GHT-01] the token master is already committed with the new serial. Put it back.
            compensateTokenMasterUpdate(existingTokenId, oldSerial, context);

            throw userUpdateException;
        }

        LOG.info("SSO token replace: user details updated successfully. " + context.describe());
    }

    /**
     * [GHT-01] Reverts the security token master to the previous serial when the user update
     * failed, so the two records do not diverge. If this itself fails the data IS inconsistent
     * and the error below is deliberately worded for log alerting.
     */
    private void compensateTokenMasterUpdate(String existingTokenId, String oldSerial,
            SSOProcessingContext context) {

        if (SSOUtils.isBlank(oldSerial)) {

            LOG.error("SSO token replace: MANUAL RECOVERY REQUIRED. User update failed and no previous "
                    + "serial was captured, so the token master cannot be reverted. tokenId=" + existingTokenId
                    + ", " + context.describe());

            return;
        }

        try {

            updateGtpSecurityToken(oldSerial, existingTokenId);

            LOG.warn("SSO token replace: user update failed, token master reverted to the previous serial. "
                    + "tokenId=" + existingTokenId + ", " + context.describe());

        } catch (Exception compensationException) {

            LOG.error("SSO token replace: MANUAL RECOVERY REQUIRED. User update failed AND the token master "
                    + "could not be reverted. The security token master and the user record are now "
                    + "inconsistent and the user cannot authenticate. tokenId=" + existingTokenId
                    + ", " + context.describe(), compensationException);
        }
    }

    private String getExistingTokenIdFromUser(GTPUser user) throws InterfaceException {

        // [GHT-27] via SSOUtils
        String tokenId = SSOUtils.safeGetUserPermValue(user, MQConstantUtil.OTP_TOKEN_ID);

        if (!SSOUtils.isBlank(tokenId)) {
            return tokenId;
        }

        return getTokenIdFromSecurityMaster(user.getIdAsString());
    }

    /**
     * [GHT-23] tokenReference parameter removed.
     */
    private void updateGtpSecurityToken(String newSerial, String existingTokenId) throws GTPException {

        try {

            if (LOG.isDebugEnabled()) {
                LOG.debug("SSO token replace: fetching security token. tokenId=" + existingTokenId);
            }

            SecurityTokenImpl token = new SecurityTokenImpl();

            BulkReferencesSet referenceSet = new BulkReferencesSet();

            // [GHT-18] constant used instead of the inline "token_id" literal
            referenceSet.add(new BulkReference(SSOConstants.TOKEN_ID, existingTokenId));

            token.retrieveFromDB(referenceSet);

            if (!token.isValid()) {
                throw new GTPException("Security token master not found for tokenId=" + existingTokenId);
            }

            token.getSerial_no().setValue(newSerial);

            updateSecurityTokenInTransaction(token);

        } catch (Exception e) {

            // [GHT-12] serial masked  [GHT-20] exception passed
            LOG.error("Error while updating security token. tokenId=" + existingTokenId
                    + ", newSerial=" + SSOUtils.maskSerial(newSerial), e);

            throw new GTPException("Error while updating security token ", e);
        }
    }

    private void updateSecurityTokenInTransaction(SecurityTokenImpl token) throws GTPException {

        try {

            SecurityTokenManager.getInstance().updateToken(token);

        } catch (Exception e) {

            throw new GTPException("Could not update security token info, " + e.getMessage());
        }
    }

    private static void updateUserDetails(GTPUser user, String tokenSerialNo, String tokenVendor)
            throws GTPException {

        try {

            user.setPerm(MQConstantUtil.OTP_TOKEN_SERIAL_NO, tokenSerialNo);

            user.setPerm(MQConstantUtil.OTP_TOKEN_VENDOR, tokenVendor);

            GTPSecurity.updateUser(user);

        } catch (Exception e) {

            throw new GTPException("Could not update user info, " + e.getMessage());
        }
    }

    private void throwValidationException(String message) throws GTPException {

        LOG.error("SSO token replace validation error: " + message);

        // TODO [GHT-36] supply a defined error code instead of null
        throw new GTPException(null, message);
    }

    /**
     * [GHT-13] Multiple-row detection added. The original had no status filter, no ORDER BY, and
     * took the first row with a bare if (rs.next()). A user carrying a revoked or historical
     * token row could have the wrong TOKEN_ID selected, and the new serial was then written onto
     * that token.
     *
     * TODO [GHT-13] ADD THE STATUS FILTER. The correct predicate depends on the SECURITY_TOKEN
     * status/active column, which is not visible in this CR. Detecting the ambiguity and failing
     * is safe but it will reject users who legitimately hold historical rows. Confirm the column
     * and add it to the WHERE clause.
     *
     * [GHT-15] userId bound with setLong.
     */
    private String getTokenIdFromSecurityMaster(String userId) throws InterfaceException {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String tokenId = "";

        try {

            con = PoolBrokerService.getConnection();

            stmt = con.prepareStatement("SELECT TOKEN_ID FROM " + TechnicalResourceProvider.TABLE_SECURITY_TOKEN
                    + " WHERE ASSIGNED_USER_ID = ?");

            // [GHT-15] was setString against a numeric column, which suppressed index usage and
            // could raise ORA-01722
            stmt.setLong(1, Long.parseLong(userId.trim()));

            rs = stmt.executeQuery();

            if (rs.next()) {

                tokenId = rs.getString(1);

                // [GHT-13] fail on ambiguity rather than silently taking the first row
                if (rs.next()) {

                    throw new InterfaceException(new GTPException(
                            "Multiple security token rows found for user. Cannot determine which token to "
                                    + "update. userId=" + userId));
                }
            }

        } catch (InterfaceException e) {

            throw e;

        } catch (Exception e) {

            LOG.error("Unexpected error retrieving token id from security master. userId=" + userId, e);

            throw new InterfaceException(e);

        } finally {

            Utils.closeResources(con, stmt, rs);
        }

        return tokenId;
    }
}
