# Revised Files — Global SSO / Hard Token Replace CR

Every change carries an inline `[GHT-xx]` comment tying it back to the findings document, so the developer can accept or reject each one individually.

## Files

| File | Status |
|---|---|
| `SSOUtils.java` | **New.** Consolidates the duplicated helpers and breaks the validator to consumer dependency |
| `SSOConstants.java` | Revised |
| `SSOProcessingContext.java` | Revised — constructor signature changed |
| `GHTAuditContext.java` | Revised |
| `SSOValidationProcessor.java` | Revised — `validateMandatoryFields` and `validateSecurityTokenDetails` signatures changed |
| `SSOMessageConsumer.java` | Revised |
| `SSOAuditProcessor.java` | Revised — `insertGlobalHardTokenAudit` signature changed |

## Signature changes

These will not compile against the existing callers without the matching file:

- `SSOProcessingContext(...)` — `jsonRequest` removed, `oldTokenSerialNo` added
- `SSOValidationProcessor.validateSecurityTokenDetails(...)` — returns `void`
- `SSOValidationProcessor.validateMandatoryFields(...)` — `participatingLoginId` added
- `SSOAuditProcessor.insertGlobalHardTokenAudit(...)` — `oldTokenSerialNo` added
- `SSOMessageConsumer.safeGetUserPermValue(...)` — moved to `SSOUtils`

## Fixed in code

GHT-02, GHT-03, GHT-04, GHT-06 (sequences), GHT-08, GHT-09, GHT-10, GHT-11, GHT-12, GHT-17, GHT-18, GHT-20, GHT-22, GHT-23, GHT-24, GHT-26, GHT-27, GHT-28, GHT-30, GHT-31, GHT-32, GHT-33, GHT-34, GHT-35, GHT-37

## Left as `TODO` — needs a decision, not a code change

| Finding | Blocked on |
|---|---|
| GHT-01 | Whether `PoolBrokerService.beginTransaction` can span `SecurityTokenManager.updateToken` and `GTPSecurity.updateUser`. A compensating rollback is implemented as mitigation; a real transaction boundary is the correct fix |
| GHT-05 | Actual column definition of `GTP_AUDIT_ITEM.CONTEXT`. The 4000 guard assumes `VARCHAR2(4000)` |
| GHT-07 | Why the portal audit API was not used. Table names still hardcoded |
| GHT-13 | The status/active column name on `SECURITY_TOKEN`. Multi-row detection is in; the filter is not |
| GHT-14 | Bank sign-off on the loopback IP placeholder |
| GHT-15 | Confirmation that `AUDIT_ID` / `COMPANY_ID` / `USER_ID` are `NUMBER` columns |
| GHT-16 | Whether a duplicate-skip needs an audit row |
| GHT-19 | Whether all fourteen fields are genuinely never blank in a valid request |
| GHT-21 | Redelivery contract. Currently implemented as log-and-drop for an unparseable payload |
| GHT-25 | Expected value of the `NAME` context field vs a portal-generated BAU row |
| GHT-29 | Whether GUID casing is guaranteed identical across systems. `equalsIgnoreCase` applied as the safer default |
| GHT-36 | The correct GEB error code for `GTPException` |

## Not covered

No JUnit coverage is included. The revised classes are structured to make it possible — `GHTAuditContext` now has getters, `SSOUtils` is stateless and independently testable, and `BauContextResult` exposes completeness — but the tests themselves still need writing.

## Correction to the findings document

GHT-32 listed `MODIFIED` and `OTP_TOKEN_ID` as unused constants. Both are referenced by `SSOAuditProcessor.populateBauUserContext` and have been kept. Only `OLD_TOKEN_SERIAL_NO`, `CHARGE_TYPE`, `REMARKS` and `OTP_TOKEN_CHARGE_TYPE` were genuinely unused and removed.
